#pragma once

#include "Arrays.h"
template <class T>
class vectors : public Arrays<T> {
 public:
  // 构造函数
  vectors() : Arrays<T>() {
    setCapacity(this->getSize());
    this->end = this->getLastPrt();
  };
  // 构造函数. 初始化数组大小
  vectors(int s) : Arrays<T>(s) {
    setCapacity(this->getSize());
    this->end = &this->operator[](this->getCapacity() - 1);
  };
  // 构造函数，初始化数组大小和初始值
  vectors(int s, int beginValue) : Arrays<T>(s, beginValue) {
    setCapacity(this->getSize());
    this->end = &this->operator[](this->getCapacity() - 1);
  }
  // 拷贝构造函数
  vectors(const Arrays<T>& arr) : Arrays<T>(arr) {
    setCapacity(this->getSize());
    this->end = &this->operator[](this->getCapacity() - 1);
  }

  void setCapacity(int);
  int getCapacity();

  virtual void push(T) override;

  virtual void pop() override;

 private:
  int capacity;
  T* end = nullptr;  // 
};

// 设置数组容量
template <class T>
void vectors<T>::setCapacity(int s) {
  this->capacity = 2 * s + 1;
}

template <class T>
int vectors<T>::getCapacity() {
  return this->capacity;
}

template <class T>
void vectors<T>::push(T value) {
  if (this->end == this->getLastPrt()) {
    this->capacity = capacity * 2 + 1;
    T* temp = new T[capacity];
    for (int i = 0; i < this->getSize(); i++) {
      temp[i] = this->operator[](i);
    }
    this->setArrays(temp);
    this->setStartPrt(this->operator[](0));
    end = &this->operator[](capacity - 1);
  }
  this->setValue(this->getSize(), value);
  this->setSize(this->getSize() + 1);
  this->setLastPrt(this->operator[](this->getSize()));
}

template <class T>
void vectors<T>::pop() {
  this->setSize(this->getSize() - 1);
  this->setLastPrt(this->operator[](this->getSize()));
}