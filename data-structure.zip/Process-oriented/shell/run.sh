echo "start to run program\n"
cd ../bin
./process_oriented
cd ../shell
echo "\nfinished"
