echo "make clean all"
cd ../build
make clean all
echo "make"
make
cd ../shell
echo "done"
