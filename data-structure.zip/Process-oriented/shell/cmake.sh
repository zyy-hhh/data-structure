echo "cleaning up all cmake cache..."
cd ../build
rm -rf CMakeCache.txt
rm -rf CMakeFiles
rm -rf Makefile
rm -rf cmake_install.cmake
rm -rf install_manifest.txt
rm -rf CMakeFiles
echo "cleaned up"
echo "generating cmake cache..."
cmake ..
cd ../shell
echo "generated"
