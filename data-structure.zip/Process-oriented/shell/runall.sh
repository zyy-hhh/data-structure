echo "cleaning up all cmake cache..."
cd ../build
rm -rf CMakeCache.txt
rm -rf CMakeFiles
rm -rf Makefile
rm -rf cmake_install.cmake
rm -rf install_manifest.txt
cd ../bin
rm -rf *
echo "cleaned up"
echo "generating cmake cache..."
cd ../build
cmake ..
echo "generated"
echo "make"
make
echo "done"
echo "start to run program\n"
cd ../bin
./process_oriented
cd ../shell
echo "\nfinished"