// 这是数据结构的复习代码 需要全部可以手写并能够无警告错误编译
// c++ 规范采用c++11
// 数据结构的复习代码
#ifndef _901_H
#define _901_H
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <queue>
#include <random>
#include <stack>
#include <vector>

#define DEBUG
// using vtri = std::vector<int>;
using str = std::string;
using tp = std::chrono::steady_clock::time_point;
using i64 = long long;
using u64 = unsigned long long;

// TESTDONE
namespace PublicUse {
// 生成随机数
int RandomNumberGenerate(int min, int max) {
  std::random_device rd;
  std::mt19937 gen(rd());
  std::uniform_int_distribution<> dis(min, max);
  return dis(gen);
}

// 计时开始函数
tp TimeStart() {
  std::cerr << "Time Start\n";
  tp t1 = std::chrono::steady_clock::now();
  return t1;
  ;
}

// 计时结束并输出时间
void TimeEnd(tp t1) {
  std::cerr << "Time End\n";
  tp t2 = std::chrono::steady_clock::now();
  auto duration =
      std::chrono::duration_cast<std::chrono::microseconds>(t2 - t1).count();
  printf("Time: %lld us\n", duration);
  printf("Tiem: %5f s\n", duration / 1000000.0);
  return;
}
}  // namespace PublicUse

// TEST DONE
namespace LinearList {
using ElemType = int;  // 定义元素类型
constexpr int MaxSize = 50;
constexpr int InitSize = 100;

// 单链表的声明
typedef struct {
  ElemType data[InitSize];  // 存储空间
  int length;               // 单链表的长度
} SqList;                   // 定义类型

// 单链表的初始化
typedef struct {
  ElemType *data;       // 存储空间
  int MaxSize, length;  // 单链表的长度
} SeqList;

// 线性表初始化
void InitList(SqList &L) {
  L.length = 0;
  return;
}

// 线性表自动创建
bool ListAutoCreate(int n, SqList &L, int min, int max, bool order) {
  if (n < 1) {
    return false;
  }
  L.length = n;
  for (int i = 0; i < n; ++i) {
    if (order) {
      L.data[i] = min + i;
    } else {
      L.data[i] = PublicUse::RandomNumberGenerate(min, max);
    }
  }
  return true;
}
// 线性表的元素插入
bool ListInsert(SqList &L, int i, ElemType e) {
  if (i < 1 || i > L.length + 1) return false;  // 判断索引是否合法
  if (L.length >= MaxSize) return false;        // 判断是否已满

  for (int j = L.length; j >= i; j--) {  // 将后面的元素依次向后移动
    L.data[j] = L.data[j - 1];
  }
  L.data[i - 1] = e;  // 将新元素插入
  L.length++;         // 单链表长度加1
  return true;
}

// 线性表的元素删除
bool ListDelete(SqList &L, int i) {
  if (i < 1 || i > L.length) return false;  // 判断索引是否合法
  // ElemType e = L.data[i - 1];               // 将删除的元素赋值给e
  for (int j = i; j < L.length; j++) {  // 将后面的元素依次向前移动
    L.data[j - 1] = L.data[j];
  }
  L.length--;  // 删除元素
  return true;
}

// 输出所有元素
bool ListOutput(SqList &L) {
  if (L.length == 0) return false;
  for (int i = 0; i < L.length; i++) {
    printf("%d  ", L.data[i]);
  }
  fprintf(stdout, "\n");
  return true;
}

// 按值查找
int LocateElem(SqList &L, ElemType e) {
  for (int i = 0; i < L.length; i++) {  // 遍历线性表
    if (L.data[i] == e) return i + 1;  // 返回第一个等于e的元素的位置
  }
  return 0;
}

// 删除最小元素，空出位置由最后一个元素填补
bool ListDeleteMin(SqList &L) {
  if (L.length == 0) return false;          // 判断是否为空
  ElemType e = L.data[0];                   // 将最小元素赋值给e
  int pos = 0;                              // 删除元素的位置
  for (int i = 0; i < L.length - 1; i++) {  //
    if (L.data[i] < e) {                    // 如果当前元素小于e
      e = L.data[i];                        // 将当前元素赋值给e
      pos = i;  // 将当前元素的位置赋值给pos
    }
  }
  L.data[pos] = L.data[L.length - 1];  // 将最后一个元素填补到删除元素的位置
  L.length--;                          // 表长度减1
  return true;
}

// 顺序表逆置 复杂度为O(1)
void Reverse(SqList &L) {
  ElemType temp;  // 临时变量
  for (int i = 0; i < L.length / 2; i++) {
    temp = L.data[i];  // 交换L.data[i]和L.data[L.length - 1 - i]
    L.data[i] = L.data[L.length - 1 - i];
    L.data[L.length - 1 - i] = temp;
  }
}

// 删除表中所有值为x的元素，复杂度为O(n)，方法1
void DeleteXFunction1(SqList &L, ElemType x) {
  int k = 0, i;
  for (i = 0; i < L.length; i++) {  // 遍历线性表
    if (L.data[i] != x) {           // 如果当前元素不等于x
      L.data[k] = L.data[i];
      k++;  // k加1
    }
  }
  L.length = k;  // 表长度更新为k
}

// 删除表中所有值为x的元素，复杂度为O(n)，方法2
void DeleteXFunction2(SqList &L, ElemType x) {
  int k = 0, i = 0;  // k为x元素值的个数，i为遍历索引
  while (i < L.length) {
    if (L.data[i] == x) {
      k++;
    } else {
      L.data[i - k] = L.data[i];  // 将当前元素前移k个位置
    }
    i++;
  }
  L.length = L.length - k;  // 表长度更新为k
}

// 删除其值在s~t之间的元素
bool DeleteRangeOrder(SqList &L, ElemType s, ElemType t) {
  int i, j;
  if (s >= t || L.length == 0) return false;  // 判断s和t是否合法
  for (i = 0; i < L.length && L.data[i] < s; i++)
    ;                               // 找到第一个大于等于s的元素
  if (i >= L.length) return false;  // 如果s比表中所有元素都大，则返回false
  for (j = i; j < L.length && L.data[j] <= t; j++)
    ;                               // 删除t之后的元素
  for (; j < L.length; i++, j++) {  // 将t之后的元素前移
    L.data[i] = L.data[j];
  }
  L.length = i;  // 更新表长
  return true;
}

// 删除乱序表中s~t之间的元素
bool DeleteRangeDisorder(SqList &L, ElemType s, ElemType t) {
  int i, k = 0;
  if (s >= t || L.length == 0) return false;  // 判断s和t是否合法
  for (i = 0; i < L.length; i++) {
    if (L.data[i] >= s && L.data[i] <= t)
      k++;  // 计算s~t之间的元素个数
    else
      L.data[i - k] = L.data[i];  // 将当前元素前移k个位置
  }
  L.length -= k;  // 更新表长
  return true;
}

// 从有序表中删除所有重复元素
bool DeleteDuplicate(SqList &L) {
  if (L.length == 0) return false;  // 判断是否为空
  int i, j;
  for (i = 0, j = 0; j < L.length; j++) {
    if (L.data[i] != L.data[j]) {  // 如果当前元素不等于前一个元素
      i++;
      L.data[i] = L.data[j];
    }
  }
  L.length = i + 1;  // 更新表长
  return true;
}

// 两个有序链表合并
bool MergeOrder(SqList &L1, SqList &L2, SqList &L3) {
  if (L1.length == 0 || L2.length == 0) return false;  // 判断是否为空
  int i, j, k;
  for (i = 0, j = 0, k = 0; i < L1.length && j < L2.length;
       k++) {                       // 合并两个有序表
    if (L1.data[i] < L2.data[j]) {  // 如果L1的元素小于L2的元素
      L3.data[k] = L1.data[i];
      i++;
    } else {  // 如果L1的元素大于L2的元素
      L3.data[k] = L2.data[j];
      j++;
    }
  }
  // 将剩余的元素插入到L3中
  for (; i < L1.length; i++, k++) L3.data[k] = L1.data[i];
  for (; j < L2.length; j++, k++) L3.data[k] = L2.data[j];
  L3.length = k;  // 更新表长
  return true;
}

// 表中存储两个顺序表
void ReverseOrder(SqList &L, int left, int right) {
  if (left >= right || right >= L.length) return;
  int mid = (left + right) / 2;
  for (int i = 0; i <= mid - left; i++) {
    ElemType temp = L.data[left + i];
    L.data[left + i] = L.data[right - i];
    L.data[right - i] = temp;
  }
}

// 交换表
void Exchange(SqList &L, int m, int n) {
  ReverseOrder(L, 0, m + n - 1);  // 将A[0,m-1]和A[m,m+n-1]交换
  ReverseOrder(L, 0, n - 1);      // 将A[0,n-1]和A[n,m+n-1]交换
  ReverseOrder(L, n, m + n - 1);  // 将A[n,m-1]和A[m,m+n-1]交换
}

// 查找第一个值等于给定值的元素，并和后面的元素进行交换
void SearchExchangeInsert(SqList &L, ElemType e) {
  int low = 0, high = L.length - 1, mid;  // 定义两个指针，分别指向表的首尾
  while (low <= high) {
    mid = (low + high) / 2;  // 找中间位置
    if (L.data[mid] == e) {
      break;
    }  // 找到元素，退出循环
    else if (L.data[mid] < e) {
      low = mid + 1;
    }  // 如果中间位置的元素小于e，则low指向中间位置的后一个位置
    else {
      high = mid - 1;
    }  // 如果中间位置的元素大于e，则high指向中间位置的前一个位置
  }
  int temp = 0;
  if (L.data[mid] == e &&
      mid != L.length - 1) {  // 如果找到元素，且不是最后一个元素
    temp = L.data[mid];
    L.data[mid] = L.data[mid + 1];
    L.data[mid + 1] = temp;
  }
  int i;
  if (low > high) {  // 如果没有找到元素，则将e插入到low位置
    for (i = L.length - 1; i > high; i--) {
      L.data[i + 1] = L.data[i];
    }
    L.data[i + 1] = e;
  }
}

}  // namespace LinearList

// TEST DONE
namespace SingleLinkedList {
using ElemType = int;

// 定义单链表节点结构
typedef struct LNode {  // 定义单链表节点结构
  ElemType data;        // 存放数据域
  struct LNode *next;   // 指针域，指向下一个节点
} LNode, *LinkList;     // 定义单链表类型

// 定义单链表节点结构
typedef struct LNodeAuto {   // 定义单链表节点结构
  ElemType data;             // 存放数据域
  int locate;                // 存放位置域
  struct LNodeAuto *next;    // 指针域，指向下一个节点
} LNodeAuto, *LinkListAuto;  // 定义单链表类型

using NodeType = LNodeAuto;
using NodePointerType = LinkListAuto;

// 初始化单链表
void InitList(NodePointerType &L) { L->next = NULL; }
// 判断单链表是否为空
bool ListEmpty(NodePointerType &L) { return (L->next == NULL); }

// 自动初始化单链表(头插法)
NodePointerType ListAutoCreateHeadInsert(NodePointerType &L, int n,
                                         bool order) {
  NodePointerType p;
  // LinkList L = new LNode;
  int InitNum = PublicUse::RandomNumberGenerate(1, 10);
#ifdef DEBUG
  InitNum = 5;
#endif
  InitList(L);
  for (int i = 0; i < n; i++) {
    p = (NodePointerType)malloc(sizeof(NodeType));
    p->data = (order ? (InitNum + i) : PublicUse::RandomNumberGenerate(1, 100));
    p->locate = i;
    p->next = L->next;
    L->next = p;
  }
  return L;
}

// 自动初始化单链表(尾插法)
NodePointerType ListAutoCreateTailInsert(NodePointerType &L, int n,
                                         bool order) {
  NodeType *s, *r = L;  // r为指向表尾的指针
  int InitNum = PublicUse::RandomNumberGenerate(1, 10);
#ifdef DEBUG
  InitNum = 5;
#endif
  for (int i = 0; i < n; i++) {
    s = (NodePointerType)malloc(sizeof(NodeType));
    s->data = (order ? (InitNum + i) : PublicUse::RandomNumberGenerate(1, 100));
    s->locate = i;
    r->next = s;  // 插入到表尾
    r = s;
  }
  r->next = NULL;
  return L;
}

// 根据序号查找节点元素值
NodeType *GetElem(NodePointerType &L, int i) {
  int j = 1;              // j为计数器
  NodeType *p = L->next;  // p指向第一个结点
  if (j == 0) {
    return L;
  }  // 如果j为0，则返回头结点
  if (i < 1) {
    return L;
  }                             // 如果i小于1，则返回空指针
  while (p != NULL && j < i) {  // 如果p不为空，且j小于i
    p = p->next;
    j++;
  }
  return p;  // 返回第i个结点
}

// 按照值来查找表节点
NodeType *LocateElem(NodePointerType &L, ElemType e) {
  NodeType *p = L->next;               // p指向第一个结点
  while (p != NULL && p->data != e) {  // 如果p不为空，且p的元素值不等于e
    p = p->next;                       // p指向下一个结点
  }
  return p;  // 返回p
}

// 后插节点操作
NodePointerType ListInsertBehind(NodePointerType &L, ElemType e, int i) {
  NodeType *s, *p;
  s = (NodePointerType)malloc(sizeof(NodeType));
  s->data = e;
  p = GetElem(L, i);
  s->next = p->next;
  p->next = s;
  return L;
}

// 前插节点操作
NodePointerType ListInsertAhead(NodePointerType &L, ElemType e, int i) {
  NodeType *s, *p;
  s = (NodePointerType)malloc(sizeof(NodeType));
  s->data = e;
  s->locate = -1;
  p = GetElem(L, i);
  s->next = p->next;
  p->next = s;
  ElemType temp = p->data;
  int temp_locate = p->locate;
  p->data = s->data;
  p->locate = s->locate;
  s->data = temp;
  s->locate = temp_locate;
  return L;
}

// 删除链表中的第i个元素
NodePointerType ListDelete(NodePointerType &L, int i) {
  NodeType *p, *q;
  p = GetElem(L, i - 1);
  q = p->next;
  p->next = q->next;
  free(q);
  /*
  删除*p的后继节点，将后继节点的值赋给*p，然后释放*q
  q = p->next;  // q指向第i+1个结点,即p的下一个结点
  p->data = p->next->data;  // p的元素值等于p的下一个结点的元素值，交换数据域
  p->next = q->next;    // p的下一个结点指向q的下一个结点,释放q
  free(q);  // 释放q
  */
  return L;
}

// 求表长
int ListLength(NodePointerType &L) {
  int j = 0;
  NodeType *p = L->next;
  while (p != NULL) {
    j++;
    p = p->next;
  }
  return j;
}

void DeleteAll(NodePointerType &L) {
  NodeType *p, *q;
  p = L->next;
  while (p != NULL) {
    q = p->next;
    free(p);
    p = q;
  }
  L->next = NULL;
}

void PrintList(NodePointerType &L) {
  NodeType *p = L->next;  // p指向第一个结点
  while (p != NULL) {
    fprintf(stderr, "%3d ", p->data);
    p = p->next;
  }
  fprintf(stderr, "\n");
  p = L->next;
  while (p != NULL) {
    fprintf(stderr, "%3d ", p->locate);
    p = p->next;
  }
  fprintf(stderr, "\n");
  return;
}

// 从尾到头输出链表
void PrintListReverse(NodePointerType &L) {
  NodeType *p = L;
  if (p->next != NULL) {  // 如果p的下一个结点不为空
    // printf("lala\n");
    PrintListReverse(p->next);
  }
  if (p != NULL) {  // 如果p不为空
    fprintf(stderr, "%3d ", p->data);
  }
  return;
}

// 删除单链表中所有值为x的节点(递归调用)
NodePointerType DeleteAllRecursive(NodePointerType &L, ElemType x) {
  if (L->next != NULL) {       // 如果L不为空
    if (L->next->data == x) {  // 如果L的下一个结点的元素值等于x
      NodeType *p = L->next;   // p指向L的下一个结点
      L->next = p->next;       // L的下一个结点指向p的下一个结点
      free(p);
      DeleteAllRecursive(L, x);
    } else {
      DeleteAllRecursive(L->next, x);
    }
  }
  return L;
}

// 删除单链表中所有值为x的节点方法一：从头到尾扫描链表删除对应元素，时间复杂度为O(n)，空间复杂度为O(1)
NodePointerType DeleteAllFirst(NodePointerType &L, ElemType x) {
  NodeType *p, *q;
  p = L;
  while (p->next != NULL) {    // 如果p的下一个结点不为空
    if (p->next->data == x) {  // 如果p的下一个结点的元素值等于x
      q = p->next;
      p->next = q->next;
      free(q);
    } else {  // 如果p的下一个结点的元素值不等于x
      p = p->next;
    }
  }
  return L;
}

// 删除单链表中所有值为x的节点方法二：采用尾插法建立单链表，时间复杂度为O(n)，空间复杂度为O(1)
NodePointerType DeleteAllSecond(NodePointerType &L, ElemType x) {
  NodeType *p = L->next, *r = L, *q;  // p指向第一个结点，r指向L
  while (p != NULL) {                 // 如果p不为空
    if (p->data != x) {
      r->next = p;  // r的下一个结点指向p
      r = p;
      p = p->next;  // p指向下一个结点
    } else {
      q = p;
      p = p->next;
      free(q);
    }
  }
  r->next = NULL;
  return L;
}

// 删除单链表中的指定元素
NodePointerType SearchAndDelete(NodePointerType &L, ElemType x) {
  NodePointerType p = L, q;
  while (p->next != NULL) {
    if (p->next->data == x) {
      q = p->next;
      p->next = q->next;
      free(q);
    } else {
      p = p->next;
    }
  }
  return L;
}
// 删除单链表中的最小元素
NodePointerType SearchAndDeleteMin(NodePointerType &L) {
  NodeType *pre = L, *p = L->next;  // pre指向头结点，p指向第一个结点
  NodeType *minpre = pre,
           *minp = p;  // minpre指向最小元素的前一个结点，minp指向最小元素
  while (p != NULL) {
    if (p->data < minp->data) {  // 如果p的元素值小于最小元素的元素值
      minpre = pre;
      minp = p;
    }
    pre = p;      // pre指向p
    p = p->next;  // p指向下一个结点
  }
  minpre->next = minp->next;  // 删除最小元素
  free(minp);
  return L;
}

// 逆置单链表
NodePointerType ReverseListFirst(NodePointerType &L) {
  NodeType *p, *r;      // p指向工作结点，r指向p结点后继结点
  p = L->next;          // p指向第一个结点
  L->next = NULL;       // 头结点的下一个结点为空
  while (p != NULL) {   // 如果p不为空
    r = p->next;        // r指向p的下一个结点
    p->next = L->next;  // p的下一个结点指向头结点的下一个结点
    L->next = p;
    p = r;
  }
  return L;
}

// 逆置单链表方法二
NodePointerType ReverseListSecond(NodePointerType &L) {
  NodeType *pre,
      *p = L->next,
      *r = p->next;  // pre指向头结点，p指向第一个结点，r指向p结点后继结点
  p->next = NULL;      // p的下一个结点为空
  while (r != NULL) {  // 如果r不为空
    pre = p;           // pre指向p
    p = r;             // p指向r
    r = r->next;       // r指向r的下一个结点
    p->next = pre;     // p的下一个结点指向pre
  }
  L->next = p;  // 头结点的下一个结点指向p
  return L;
}

// 将一个链表重排为升序
NodePointerType SoarList(NodePointerType &L) {
  NodeType *p, *pre,
      *r;  // p指向工作结点，q指向p结点后继结点，r指向q结点后继结点
  p = L->next;
  r = p->next;
  p->next = NULL;
  p = r;
  while (p != NULL) {
    r = p->next;
    pre = L;
    while (pre->next != NULL && pre->next->data < p->data) {
      pre = pre->next;
    }
    p->next = pre->next;  // p的下一个结点指向pre的下一个结点
    pre->next = p;        // pre的下一个结点指向p
    p = r;                // p指向r
  }
  return L;
}

// 查看两个链表的公共节点
NodePointerType SearchCommonNodeHard(NodePointerType &L1, NodePointerType &L2) {
  int len1 = 0, len2 = 0,
      dist =
          0;  // len1为链表L1的长度，len2为链表L2的长度，dist为两个链表的长度差
  len1 = ListLength(L1);  // 计算链表L1的长度
  len2 = ListLength(L2);  // 计算链表L2的长度

  NodePointerType longList = NULL,
                  shortList = NULL;  // longList指向长链表，shortList指向短链表
  if (len1 > len2) {       // 如果链表L1的长度大于链表L2的长度
    longList = L1->next;   // longList指向链表L1的第一个结点
    shortList = L2->next;  // shortList指向链表L2的第一个结点
    dist = len1 - len2;    // 计算两个链表的长度差
  } else {
    longList = L2->next;   // longList指向链表L2的第一个结点
    shortList = L1->next;  // shortList指向链表L1的第一个结点
    dist = len2 - len1;    // 计算两个链表的长度差
  }
  while (dist--) {  // 如果链表L1的长度大于链表L2的长度
    longList = longList->next;
  }
  while (longList != NULL) {  // 如果longList不为空
    if (longList == shortList) {
      fprintf(stderr, "公共节点为：%d\n", longList->data);
      return longList;
    } else {  // 如果longList不等于shortList
      longList = longList->next;
      shortList = shortList->next;
    }
  }
  return NULL;
}

// 递增持续输出链表中的最小/大元素，并删除
void MinDelete(NodePointerType &L) {
  NodeType *u = NULL;
  while (L->next != NULL) {
    NodeType *pre = L;
    NodeType *p = pre->next;
    while (p->next != NULL) {
      if (p->next->data <
          pre->next->data) {  // 如果p的下一个结点的值小于pre的下一个结点的值
        pre = p;
      }
      p = p->next;  // p指向p的下一个结点
    }
    fprintf(stderr, "%3d ", pre->next->data);  // 输出最小元素
    u = pre->next;                             // 删除最小元素
    pre->next = u->next;
    free(u);
  }
  fprintf(stderr, "\n");
  free(L);
  return;
}

// 将链表按照元素序号的奇偶拆分为两个链表
NodePointerType DisCreate(NodePointerType &A) {
  int i = 0;
  NodePointerType B = (NodePointerType)malloc(sizeof(NodeType));
  B->next = NULL;
  NodeType *ra = A, *rb = B, *p;

  p = A->next;
  A->next = NULL;

  while (p != NULL) {
    i++;
    if (i % 2 == 0) {
      rb->next = p;
      rb = p;
    } else {
      ra->next = p;
      ra = p;
    }
    p = p->next;
  }
  ra->next = NULL;
  rb->next = NULL;
  return B;
}

// 设链表表示为(a1,b1,a2,b2,a3,b3,...),设计算法进行链表的拆分
NodePointerType DisCreate2(NodePointerType &L) {
  NodePointerType B =
      (NodePointerType)malloc(sizeof(NodeType));  // B指向链表L的头结点
  B->next = NULL;                                 // B的下一个结点为空
  NodeType *p = L->next, *q = B;  // p指向L的第一个结点，q指向B的头结点
  NodeType *ra = L;               // ra指向A的尾结点
  while (p != NULL) {
    ra->next = p;
    ra = p;               // 将p指向的结点插入到A的尾部
    p = p->next;          // p指向下一个结点
    if (p != NULL) {      // 如果p不为空
      q = p->next;        // q指向p的下一个结点
      p->next = B->next;  // 将p的下一个结点指向B的头结点
      B->next = p;        // 将p指向B的头结点
      p = q;              // p指向q
    }
  }
  ra->next = NULL;  // 将A的尾结点指向空
  return B;         // 返回B
}

// 删除递增链表中的重复元素
void DeleteRepeat(NodePointerType &L) {
  NodeType *p = L->next, *q = p->next;
  while (p != NULL && q != NULL) {
    if (p->data == q->data) {
      NodeType *t = q;
      p->next = q->next;
      q = q->next;
      free(t);
    } else {
      p = p->next;
      q = q->next;
    }
  }
}

// 将两个有序链表合并为一个递增有序链表
NodePointerType MergeListAscend(NodePointerType &L1, NodePointerType &L2) {
  NodeType *p1 = L1->next,
           *p2 = L2->next;  // p1指向L1的第一个结点，p2指向L2的第一个结点
  NodeType *p = L1;
  while (p1 != NULL && p2 != NULL) {  // 如果p1和p2都不为空
    if (p1->data < p2->data) {        // 如果p1的值小于p2的值
      p->next = p1;
      p1 = p1->next;
    } else {
      p->next = p2;
      p2 = p2->next;
    }
    p = p->next;
  }
  if (p1 != NULL) {  // 如果p1不为空
    p->next = p1;
  } else {
    p->next = p2;
  }
  return L1;
}

// 将两个有序链表合并为一个递减有序链表
NodePointerType MergeListDescend(NodePointerType &L1, NodePointerType &L2) {
  NodeType *r, *pa = L1->next,
               *pb = L2->next;  // pa指向L1的第一个结点，pb指向L2的第一个结点
  L1->next = NULL;  // 将L1的头结点指向空

  while (pa != NULL && pb != NULL) {
    if (pa->data <= pb->data) {  // 如果pa的值大于pb的值
      r = pa->next;              // r指向pa的下一个结点
      pa->next = L1->next;       // 将pa插入到L1的头结点之前
      L1->next = pa;             // 将pa插入到L1的头结点之后
      pa = r;                    // pa指向r
    } else {
      r = pb->next;         // r指向pb的下一个结点
      pb->next = L1->next;  // 将pb插入到L1的头结点之前
      L1->next = pb;        // 将pb插入到L1的头结点之后
      pb = r;               // pb指向r
    }
  }
  if (pa) {
    pb = pa;
  }                       // 如果pa不为空，则pb指向pa
  while (pb) {            // 如果pb不为空,剩下一个链表非空
    r = pb->next;         // r指向pb的下一个结点
    pb->next = L1->next;  // 将pb插入到L1的头结点之前
    L1->next = pb;        // 将pb插入到L1的头结点之后
    pb = r;               // pb指向r
  }
  free(L2);
  return L1;
}

// 从A、B链表中获取到公共元素组成新链表C
NodePointerType GetCommon(NodePointerType &A, NodePointerType &B) {
  NodeType *p = A->next,
           *q = B->next;  // p指向A的第一个结点，q指向B的第一个结点
  NodeType *r, *s;  // r指向C的第一个结点，s指向C的最后一个结点
  NodePointerType C = (NodeType *)malloc(sizeof(NodeType));  // 创建一个新链表C
  r = C;  // r指向C的尾结点
  int i = 0;
  while (p != NULL && q != NULL) {
    if (p->data < q->data) {
      p = p->next;
    }  //如果p的值小于q的值，则p指向p的下一个结点
    else if (p->data > q->data) {
      q = q->next;
    }       // 如果p的值大于q的值，则q指向q的下一个结点
    else {  // 如果p的值等于q的值
      s = (NodeType *)malloc(sizeof(NodeType));  // 创建一个新结点
      s->data = p->data;                         // 将p的值赋给s
      s->locate = i;
      s->next = NULL;  // 将s的下一个结点指向空
      r->next = s;     // 将s插入到C的尾结点之前
      r = s;           // r指向s
      p = p->next;     // p指向p的下一个结点
      q = q->next;     // q指向q的下一个结点
    }
    i++;
  }
  r->next = NULL;  // 将r的下一个结点指向空
  return C;
}

// 判断序列B是否是序列A的连续子序列
bool IsSubsequence(NodePointerType &A, NodePointerType &B) {
  NodeType *p = A->next,
           *q = B->next;  // p指向A的第一个结点，q指向B的第一个结点
  NodeType *pre = p;      // r指向A的工作开始结点
  while (p != NULL && q != NULL) {  // 如果p和q都不为空
    if (p->data == q->data) {       // 如果p的值等于q的值
      p = p->next;                  // p指向p的下一个结点
      q = q->next;                  // q指向q的下一个结点
    } else {
      pre = pre->next;  // p指向p的下一个结点
      p = pre->next;    // p指向pre的下一个结点
      q = B;            // q指向B的第一个结点
    }
  }
  if (q == NULL) {
    return true;
  } else {
    return false;
  }
}

}  // namespace SingleLinkedList

// TEST DONE
namespace DoubleLinkedList {
using ElemType = int;
// 双链表节点定义
typedef struct DNode {
  ElemType data;        // 数据域
  struct DNode *prior;  // 前驱指针
  struct DNode *next;   // 后继指针
} DNode, *DLinkList;    // 定义双链表类型

// 初始化双链表
DLinkList InitList(DLinkList &L) {
  L = (DLinkList)malloc(sizeof(DNode));  // 建立头结点
  L->prior = NULL;
  L->next = NULL;
  return L;
}

// 判断双链表是否为空
bool ListEmpty(DLinkList &L) {
  if (L->next == NULL) {
    return true;
  } else {
    return false;
  }
}

// 头插法建立双链表
DLinkList ListInsertHead(DLinkList &L, ElemType e) {
  DNode *s;
  s = (DNode *)malloc(sizeof(DNode));
  s->data = e;
  s->next = L->next;
  s->prior = L;
  L->next = s;
  if (s->next != NULL) {
    s->next->prior = s;
  }
  return L;
}

// 尾插入法建立双链表
DLinkList ListInsertTail(DLinkList &L, ElemType e) {
  DNode *s, *tmp = L;
  s = (DNode *)malloc(sizeof(DNode));
  s->data = e;
  s->next = NULL;
  while (tmp->next != NULL) {
    tmp = tmp->next;
  }
  s->prior = tmp;
  tmp->next = s;
  return L;
}

// 获取链表头节点
ElemType ListGetHead(DLinkList &L) {
  return L->next->data;  // 返回头结点的元素值
}

// 获取链表第i个元素
ElemType ListGetElement(DLinkList &L, int i) {
  DNode *p = L->next;  // p指向第一个结点
  int j = 1;
  while (p != NULL && j < i) {  // 如果p不为空，且j小于i
    p = p->next;
    j++;
  }
  return p->data;
}

// 删除链表中的第i个元素
DLinkList ListDelete(DLinkList &L, int i) {
  DNode *p, *q;
  p = L->next;  // p指向第一个结点
  int j = 1;
  while (p != NULL && j < i) {  // 如果p不为空，且j小于i
    p = p->next;                // p指向第i个结点
    j++;
  }
  q = p->next;          // q指向第i+1个结点
  p->prior->next = q;   // p的前驱结点的后继结点指向q
  q->prior = p->prior;  // q的前驱结点指向p的前驱结点
  free(p);              // 释放p
  return L;
}

// 获取链表长度
int ListLength(DLinkList &L) {
  int j = 0;
  DNode *p = L->next;  // p指向第一个结点
  while (p != NULL) {  // 如果p不为空
    j++;
    p = p->next;
  }
  return j;
}

// 输出链表中元素
void ListDisplay(DLinkList &L) {
  DNode *p = L->next;  // p指向第一个结点
  while (p != NULL) {  // 如果p不为空
    printf("%d ", p->data);
    p = p->next;
  }
  printf("\n");
}

// 新型双链表节点定义
typedef struct DFNode {
  ElemType data;         // 数据域
  struct DFNode *prior;  // 前驱指针
  struct DFNode *next;   // 后继指针
  int freq;              // 访问频度
} DFNode, *DFLinkList;   // 定义双链表类型

// 尾插入法建立双链表
DFLinkList ListInsertTail(DFLinkList &L, ElemType e) {
  DFNode *s, *tmp = L;
  s = (DFNode *)malloc(sizeof(DFNode));
  s->data = e;
  s->next = NULL;
  while (tmp->next != NULL) {
    tmp = tmp->next;
  }
  s->prior = tmp;
  tmp->next = s;
  return L;
}

// 根据元素值查找元素后，增加频度，进行排序,返回符合条件的节点
DFNode *ListInsertSort(DFLinkList &L, ElemType e) {
  DFNode *p = L->next, *q;             // p指向第一个结点
  while (p != NULL && p->data != e) {  // 如果p不为空，且p的元素值不等于e
    p = p->next;                       // p指向下一个结点
  }
  if (p == NULL) {
    exit(0);
  } else {
    p->freq++;
    if (p->prior == L || p->prior->freq > p->freq) {
      return p;
    }
    if (p->next == NULL) {
      p->next->prior = p->prior;
    }
    p->prior->next = p->next;  // p的前驱结点的后继结点指向p的后继结点,摘掉p
    q = p->prior;  // q指向p的前驱结点
    while (q != L && q->freq <= p->freq) {
      q = q->prior;
    }
    p->next = q->next;
    if (q->next != NULL) {
      q->next->prior = p;
    }
    p->prior = q;
    q->next = p;
  }
  return p;
}

DFLinkList ListAutoInit(DFLinkList &L, int n) {
  L = (DFLinkList)malloc(sizeof(DFNode));  // 建立头结点
  L->prior = NULL;
  L->next = NULL;
  L->freq = 1;
  for (int i = 1; i < n; i++) {
    ListInsertTail(L, PublicUse::RandomNumberGenerate(1, 3));
  }
  return L;
}

// 输出元素
// 输出链表中元素
void ListDisplay(DFLinkList &L) {
  DFNode *p = L->next;  // p指向第一个结点
  while (p != NULL) {   // 如果p不为空
    printf("%d:%d ", p->data, p->freq);
    p = p->next;
  }
  printf("\n");
}
}  // namespace DoubleLinkedList

// TEST DONE
namespace CircularSingleLinkedList {
using ElemType = int;
// 循环单链表节点定义
typedef struct CNode {
  ElemType data;       // 数据域
  struct CNode *next;  // 后继指针
} CNode, *CLinkList;   // 定义循环单链表类型

// 初始化循环单链表
CLinkList InitList(CLinkList &L) {
  L = (CLinkList)malloc(sizeof(CNode));  // 建立头结点
  L->next = L;                           // 头结点的后继指针指向自己
  return L;
}

// 判断循环单链表是否为空
bool ListEmpty(CLinkList &L) {
  if (L->next == L) {
    return true;
  } else {
    return false;
  }
}

// 头插法建立循环单链表
CLinkList ListInsertHead(CLinkList &L, ElemType e) {
  CNode *s;                            // s指向新结点
  s = (CNode *)malloc(sizeof(CNode));  // 建立新结点
  s->data = e;                         // 存储元素
  s->next = L->next;  // 新结点的后继指针指向原链表的第一个结点
  L->next = s;        // 头结点的后继指针指向新结点
  return L;
}

// 尾插法建立循环单链表
CLinkList ListInsertTail(CLinkList &L, ElemType e) {
  CNode *s, *p;  // s指向新结点，p指向循环单链表的最后一个结点
  s = (CNode *)malloc(sizeof(CNode));  // 建立新结点
  s->data = e;                         // 存储元素
  s->next = NULL;                      // 新结点的后继指针指向空
  p = L->next;            // p指向循环单链表的第一个结点
  while (p->next != L) {  // 如果p的后继不是头结点
    p = p->next;
  }
  p->next = s;  // p的后继指针指向新结点
  s->next = L;  // 新结点的后继指针指向头结点
  return L;
}

// 获取循环单链表头节点
ElemType ListGetHead(CLinkList &L) {
  ElemType e = L->next->data;  // 返回头结点的元素值
  return e;
}

// 获取循环单链表第i个元素
ElemType ListGetElement(CLinkList &L, int i) {
  CNode *p = L->next;  // p指向第一个结点
  int j = 1;
  while (p != L && j < i) {  // 如果p不为空，且j小于i
    p = p->next;
    j++;
  }
  return p->data;
}

// 删除循环单链表中的第i个元素
CLinkList ListDelete(CLinkList &L, int i) {
  CNode *p, *q;
  p = L->next;  // p指向第一个结点
  int j = 1;
  while (p != L && j < i) {  // 如果p不为空，且j小于i
    p = p->next;             // p指向第i个结点
    j++;
  }
  q = p->next;        // q指向第i+1个结点
  p->next = q->next;  // p的后继指针指向q的后继
  free(q);            // 释放q
  return L;
}

// 将第二个链表链接到第一个链表后构成新的循环链表
CLinkList ListLink(CLinkList &L1, CLinkList &L2) {
  CNode *p = L1, *q = L2;
  while (p->next != L1) {  // 如果p不为空，且p的后继不是头结点
    p = p->next;
  }
  while (q->next != L2) {  // 如果q不为空，且q的后继不是头结点
    q = q->next;
  }
  p->next = L2;  // p的后继指针指向L2
  q->next = L1;  // q的后继指针指向L1
  return L1;
}

// 输出链表元素
void ListDisplay(CLinkList &L) {
  CNode *p = L->next;  // p指向第一个结点
  while (p != L) {     // 如果p不为空，且p的后继不是头结点
    fprintf(stderr, "%d ", p->data);
    p = p->next;
  }
  fprintf(stderr, "\n");
  return;
}

// 带头节点的循环单链表每次查找最小值并删除，最后删除头节点
void ListDeleteMin(CLinkList &L) {
  CNode *p, *pre, *minp,
      *minpre;  // p指向循环单链表的第一个结点，pre指向p的前驱，minp指向循环单链表中最小值的结点，minpre指向minp的前驱
  while (L->next != L) {  // 如果L不为空，且L的后继不是头结点
    p = L->next;          // p指向第一个结点
    pre = L;              // pre指向头结点
    minp = p;             // minp指向第一个结点
    minpre = pre;         // minpre指向头结点
    while (p != L) {      // 如果p不为头结点
      if (p->data < minp->data) {  // 如果p的元素值小于minp的元素值
        minp = p;
        minpre = pre;
      }
      pre = p;      // pre指向p
      p = p->next;  // p指向p的后继
    }
    minpre->next = minp->next;
    free(minp);
    ListDisplay(L);
  }
  free(L);
  return;
}

}  // namespace CircularSingleLinkedList

// TEST DONE
namespace CircularDoubleLinkedList {
using ElemType = int;
// 循环双链表节点定义
typedef struct CDNode {
  ElemType data;         // 数据域
  struct CDNode *prior;  // 前驱指针
  struct CDNode *next;   // 后继指针
} CDNode, *CDLinkList;   // 定义循环双链表类型

// 初始化循环双链表
CDLinkList InitList(CDLinkList &L) {
  L = (CDLinkList)malloc(sizeof(CDNode));  // 建立头结点
  L->prior = L;  // 头结点的前驱指针指向自己
  L->next = L;   // 头结点的后继指针指向自己
  return L;
}

// 判断循环双链表是否为空
bool ListEmpty(CDLinkList &L) {
  if (L->next == L) {
    return true;
  } else {
    return false;
  }
}

// 头插法建立循环双链表
CDLinkList ListInsertHead(CDLinkList &L, ElemType e) {
  CDNode *s;                             // s指向新结点
  s = (CDNode *)malloc(sizeof(CDNode));  // 建立新结点
  s->data = e;                           // 存储元素
  s->next = L->next;  // 新结点的后继指针指向原链表的第一个结点
  s->prior = L;       // 新结点的前驱指针指向头结点
  L->next->prior = s;  // 头结点的后继指针指向新结点
  L->next = s;         // 头结点的后继指针指向新结点
  return L;
}

// 尾插法建立循环双链表
CDLinkList ListInsertTail(CDLinkList &L, ElemType e) {
  CDNode *s;                             // s指向新结点
  s = (CDNode *)malloc(sizeof(CDNode));  // 建立新结点
  s->data = e;                           // 存储元素
  s->prior = L->prior;  // 新结点的前驱指针指向原链表的第一个结点
  s->next = L;  // 新结点的后继指针指向原链表的第一个结点
  L->prior->next = s;  // 头结点的前驱指针指向新结点
  L->prior = s;        // 头结点的前驱指针指向新结点
  return L;
}

// 获取循环双链表头节点
ElemType ListGetHead(CDLinkList &L) {
  ElemType e = L->next->data;  // 返回头结点的元素值
  return e;
}

// 获取循环双链表第i个元素
ElemType ListGetElement(CDLinkList &L, int i) {
  CDNode *p = L->next;  // p指向第一个结点
  int j = 1;
  while (p != L && j < i) {  // 如果p不为空，且j小于i
    p = p->next;
    j++;
  }
  return p->data;
}

// 删除循环双链表中的第i个元素
CDLinkList ListDelete(CDLinkList &L, int i) {
  CDNode *p, *q;
  p = L->next;  // p指向第一个结点
  int j = 1;
  while (p != L && j < i) {  // 如果p不为空，且j小于i
    p = p->next;
    j++;
  }
  if (p == L) {
    fprintf(stderr, "删除失败！\n");
    // return L;
  } else {
    q = p->next;
    p->prior->next = q;
    q->prior = p->prior;
    free(p);
    // return L;
  }
  return L;
}

// 获取循环双链表长度
int ListLength(CDLinkList &L) {
  CDNode *p = L->next;  // p指向第一个结点
  int i = 0;
  while (p != L) {  // 如果p不为空
    p = p->next;
    i++;
  }
  return i;
}

// 判断循环双链表是否对称
bool ListIsSymmetry(CDLinkList &L) {
  CDNode *p = L->next;   // p指向第一个结点
  CDNode *q = L->prior;  // q指向最后一个结点
  while (p != q) {       // 如果p不为空，且q不为空
    if (p->data != q->data) {
      return false;
    }
    p = p->next;
    q = q->prior;
  }
  return true;
}

// 顺序输出循环链表元素
void ListDisplay(CDLinkList &L) {
  CDNode *p = L->next;  // p指向第一个结点
  while (p != L) {      // 如果p不为空
    fprintf(stderr, "%d ", p->data);
    p = p->next;
  }
  fprintf(stderr, "\n");
}

// 逆序输出循环链表元素
void ListDisplayReverse(CDLinkList &L) {
  CDNode *p = L->prior;  // p指向最后一个结点
  while (p != L) {       // 如果p不为空
    fprintf(stderr, "%d ", p->data);
    p = p->prior;
  }
  fprintf(stderr, "\n");
}
}  // namespace CircularDoubleLinkedList

// TEST DONE
namespace SqStack {
using ElemType = int;
constexpr int MaxSize = 50;

// 定义栈结点
typedef struct {
  int data[MaxSize];  // 数据域
  int top;            // 栈顶指针
} SqStack;

// 初始化栈
void InitStack(SqStack &S) { S.top = -1; }

// 判断栈是否为空
bool StackEmpty(SqStack S) { return S.top == -1; }

// 进栈
bool Push(SqStack &S, ElemType e) {
  if (S.top == MaxSize - 1) {
    std::cout << "栈满" << std::endl;
    return false;
  }
  S.top++;
  S.data[S.top] = e;
  return true;
}

// 出栈
bool Pop(SqStack &S, ElemType &e) {
  if (S.top == -1) {
    fprintf(stderr, "栈空\n");
    return false;
  }
  e = S.data[S.top];
  S.top--;
  return true;
}

// 自顶向下输出元素
void StackDisplay(SqStack &S) {
  if (S.top == -1) {
    fprintf(stderr, "栈空\n");
    return;
  }
  for (int i = S.top; i >= 0; i--) {
    fprintf(stderr, "%d ", S.data[i]);
  }
  fprintf(stderr, "\n");
}
// 获取栈顶元素
bool GetTop(SqStack S, ElemType &e) {
  if (S.top == -1) {
    fprintf(stderr, "栈空\n");
    return false;
  }
  e = S.data[S.top];
  return true;
}

// 获取栈长
int StackLength(SqStack S) { return S.top + 1; }

// 定义共享栈
typedef struct {
  int data[MaxSize];  // 数据域
  int top[2];         // 栈顶指针
} SqShareStack;

// 初始化共享栈
void init(SqShareStack &S) {
  S.top[0] = -1;
  S.top[1] = MaxSize;
}

// 共享栈元素入栈:栈指针，元素，插入栈序号
bool push(SqShareStack &S, ElemType e, int i) {
  if (i < 0 || i > 1) {
    fprintf(stderr, "输入栈号错误");
    return false;
  }
  if (S.top[1] - S.top[0] == 1) {
    fprintf(stderr, "栈满");
    return false;
  }
  switch (i) {
    case 0:
      S.top[0]++;
      S.data[S.top[0]] = e;
      break;
    case 1:
      S.top[1]--;
      S.data[S.top[1]] = e;
      break;
  }
  return true;
}

// 共享栈元素出栈：栈指针，出栈元素，出栈栈序号
bool pop(SqShareStack &S, ElemType &e, int i) {
  if (i < 0 || i > 1) {
    printf("输入栈号错误");
    return false;
  }
  switch (i) {
    case 0:
      if (S.top[0] == -1) {
        printf("栈空");
        return false;
      } else {
        e = S.data[S.top[0]];
        S.top[0]--;
        return true;
      }
      break;
    case 1:
      if (S.top[1] == MaxSize) {
        printf("栈空");
        return false;
      } else {
        e = S.data[S.top[1]];
        S.top[1]++;
        return true;
      }
      break;
  }
  return true;
}

// 共享栈元素输出：栈指针，输出栈序号
void display(SqShareStack &S, int i) {
  if (i < 0 || i > 1) {
    fprintf(stderr, "输入栈号错误");
    return;
  }
  switch (i) {
    case 0:
      if (S.top[0] == -1) {
        fprintf(stderr, "栈空");
        return;
      } else {
        for (int i = S.top[0]; i >= 0; i--) {
          fprintf(stderr, "%d ", S.data[i]);
        }
        fprintf(stderr, "\n");
      }
      break;
    case 1:
      if (S.top[1] == MaxSize) {
        fprintf(stderr, "栈空");
        return;
      } else {
        for (int i = S.top[1]; i < MaxSize; i++) {
          fprintf(stderr, "%d ", S.data[i]);
        }
        fprintf(stderr, "\n");
      }
      break;
  }
}
}  // namespace SqStack

// TEST DONE
namespace LinkStack {
using ElemType = char;
constexpr int MaxSize = 10;
// 定义链栈结点
typedef struct LNode {
  ElemType data;
  struct LNode *next;
} LNode, *LinkStack;

// 初始化链栈
void InitStack(LinkStack &S) { S = NULL; }

// 判断链栈是否为空
bool StackEmpty(LinkStack S) { return S == NULL; }

// 进栈
bool Push(LinkStack &S, ElemType e) {
  LinkStack p = new LNode;
  p->data = e;
  p->next = S;
  S = p;
  return true;
}

// 出栈
bool Pop(LinkStack &S, ElemType &e) {
  if (S == NULL) {
    fprintf(stderr, "栈空\n");
    return false;
  }
  e = S->data;
  LinkStack p = S;
  S = S->next;
  delete p;
  return true;
}

// 获取栈顶元素
bool GetTop(LinkStack S, ElemType &e) {
  if (S == NULL) {
    std::cout << "栈空" << std::endl;
    return false;
  }
  e = S->data;
  return true;
}

// 获取栈长
int StackLength(LinkStack &S) {
  int i = 0;
  LinkStack p = S;
  while (p != NULL) {
    p = p->next;
    i++;
  }
  return i;
}

// 判断栈是否为满
bool StackFull(LinkStack &S) {
  int count = 0;
  LinkStack p = S;
  while (p != NULL) {
    p = p->next;
    count++;
  }
  if (count >= MaxSize) {
    return true;
  } else {
    return false;
  }
}

// 自顶向下输出栈元素
void Display(LinkStack &S) {
  LinkStack p = S;
  while (p != NULL) {
    fprintf(stderr, "%d ", p->data);
    p = p->next;
  }
  fprintf(stderr, "\n");
}
// 判断链表是否中心对称
bool IsSymmetrical(LinkStack &S, int n) {
  int i;
  ElemType s[n / 2];
  LNode *p = S;  // p指向链表的第一个结点
  for (i = 0; i < n / 2; i++) {
    s[i] = p->data;
    p = p->next;
  }
  i--;
  if (n % 2 == 1) {
    p = p->next;
  }
  while (p != NULL && s[i] == p->data) {
    p = p->next;
    i--;
  }
  if (i == -1) {
    return true;
  } else {
    return 0;
  }
}

// 运用两个栈来模拟队列的实现
// 初始化队列
void InitQueue(LinkStack &S1, LinkStack &S2) {
  InitStack(S1);
  InitStack(S2);
}

// 入队
bool EnQueue(LinkStack &S1, LinkStack &S2, ElemType e) {
  if (!StackFull(S1)) {
    Push(S1, e);
    return true;
  }
  if (StackFull(S1) && !StackEmpty(S2)) {
    fprintf(stderr, "队列满\n");
    return false;
  }
  if (StackFull(S1) && StackEmpty(S2)) {
    while (!StackEmpty(S1)) {
      Pop(S1, e);
      Push(S2, e);
    }
  }
  Push(S1, e);
  return true;
}

// 出队
bool DeQueue(LinkStack &S1, LinkStack &S2, ElemType &e) {
  if (!StackEmpty(S2)) {
    Pop(S2, e);
    return true;
  } else if (StackEmpty(S1)) {
    fprintf(stderr, "队列空\n");
    return false;
  } else {
    while (!StackEmpty(S1)) {
      Pop(S1, e);
      Push(S2, e);
    }
    Pop(S2, e);
  }
  return true;
}

bool QueueEmpty(LinkStack S1, LinkStack S2) {
  if (StackEmpty(S1) && StackEmpty(S2)) {
    return true;
  } else {
    return false;
  }
}

// 括号匹配问题
bool Match(char *str) {
  LinkStack S;
  InitStack(S);
  int i = 0;
  char e;
  while (str[i] != '\0') {
    switch (str[i]) {
      // 左括号入栈
      case '(':
        Push(S, '(');
        break;
      case '[':
        Push(S, '[');
        break;
      case '{':
        Push(S, '{');
        break;
      // 右括号判断
      case ')':
        Pop(S, e);
        if (e != '(') return false;
        break;
      case ']':
        Pop(S, e);
        if (e != '[') return false;
        break;
      case '}':
        Pop(S, e);
        if (e != '{') return false;
        break;
      default:
        break;
    }
    i++;
  }
  if (StackEmpty(S)) {
    fprintf(stderr, "匹配成功\n");
    return true;
  } else {
    fprintf(stderr, "匹配失败\n");
    return false;
  }
}
}  // namespace LinkStack

// TEST DONE
namespace SQueue {
using ElemType = int;
constexpr int MaxSize = 50;

// 定义队列
typedef struct SqQueue {
  ElemType data[MaxSize];
  int front, rear;
} SqQueue;

// 初始化队列
void InitQueue(SqQueue &Q) { Q.front = Q.rear = 0; }

// 判断队列是否为空
bool QueueEmpty(SqQueue &Q) { return Q.front == Q.rear; }

// 入队
bool EnQueue(SqQueue &Q, ElemType e) {
  if (Q.rear == MaxSize) {
    std::cout << "队列满" << std::endl;
    return false;
  }
  Q.data[Q.rear] = e;
  Q.rear++;
  return true;
}

// 出队
bool DeQueue(SqQueue &Q, ElemType &e) {
  if (Q.front == Q.rear) {
    std::cout << "队列空" << std::endl;
    return false;
  }
  e = Q.data[Q.front];
  Q.front++;
  return true;
}

// 读队头元素
bool GetHead(SqQueue Q, ElemType &e) {
  if (Q.front == Q.rear) {
    std::cout << "队列空" << std::endl;
    return false;
  }
  e = Q.data[Q.front];
  return true;
}

// 输出队列元素
void QueueDisplay(SqQueue &Q) {
  for (int i = Q.front; i < Q.rear; i++) {
    fprintf(stderr, "%d ", Q.data[i]);
  }
  fprintf(stderr, "\n");
}

typedef struct SqRQueue {
  ElemType data[MaxSize];
  int front, rear;
  int size;
} SqRQueue;

// 初始化队列
void InitQueueRecursive(SqRQueue &Q) {
  Q.front = Q.rear = 0;
  Q.size = 0;
}

// 判断队列是否为空
bool QueueEmptyRecursive(SqRQueue &Q) {
  return (Q.front == Q.rear && Q.size == 0);
}

// 入队
bool EnQueueRecursive(SqRQueue &Q, ElemType e) {
  if ((Q.rear + 1) % MaxSize == Q.front && Q.size == MaxSize) {
    std::cout << "队列满" << std::endl;
    return false;
  }
  Q.data[Q.rear] = e;
  Q.rear = (Q.rear + 1) % MaxSize;
  Q.size++;
  return true;
}

// 出队
bool DeQueueRecursive(SqRQueue &Q, ElemType &e) {
  if (Q.front == Q.rear && Q.size == 0) {
    std::cout << "队列空" << std::endl;
    return false;
  }
  e = Q.data[Q.front];
  Q.front = (Q.front + 1) % MaxSize;
  Q.size--;
  return true;
}

// 输出队列元素
void QueueDisplayRecursive(SqRQueue &Q) {
  if (Q.front == Q.rear && Q.size == 0) {
    fprintf(stderr, "队列空\n");
    return;
  }
  for (int i = Q.front; i != Q.rear; i = (i + 1) % MaxSize) {
    fprintf(stderr, "%d ", Q.data[i]);
  }
  fprintf(stderr, "\n");
}
}  // namespace SQueue

// TEST DONE
namespace LinkQueue {
using ElemType = int;
constexpr int MaxSize = 50;

// 定义链队列节点信息
typedef struct LinkNode {  // 链表结点
  ElemType data;
  struct LinkNode *next;
} LinkNode;

// 初始化链队列
typedef struct LinkQueue {  // 定义链队列
  LinkNode *front, *rear;   // 队头和队尾指针
} LinkQueue;

// 初始化链队列
void initLinkQueue(LinkQueue &Q) {
  Q.front = Q.rear =
      (LinkNode *)malloc(sizeof(LinkNode));  // 初始化队头和队尾指针
  Q.front->next = NULL;                      // 初始化为空
}

// 判断链队列是否为空
bool isLinkQueueEmpty(LinkQueue Q) {
  if (Q.front == Q.rear)
    return true;
  else
    return false;
}

// 入队
void enLinkQueue(LinkQueue &Q, ElemType e) {
  LinkNode *s;
  s = (LinkNode *)malloc(sizeof(LinkNode));
  s->data = e;
  s->next = NULL;
  Q.rear->next = s;
  Q.rear = s;
}

// 出队
bool deLinkQueue(LinkQueue &Q, ElemType &e) {
  if (Q.front == Q.rear) return false;  // 队列为空
  LinkNode *p;
  p = Q.front->next;
  e = p->data;
  Q.front->next = p->next;
  if (Q.rear == p) Q.rear = Q.front;  // 如果原队列中只有一个结点，删除后变空
  free(p);
  return true;
}

// 输出队列元素
void displayLinkQueue(LinkQueue &Q) {
  LinkNode *p;
  p = Q.front->next;
  while (p != NULL) {
    fprintf(stderr, "%d ", p->data);
    p = p->next;
  }
  fprintf(stderr, "\n");
}
}  // namespace LinkQueue

// TEST DONE
namespace Template_test {
constexpr int MaxSize = 10;
constexpr int DefaultData = 0;
template <typename T>
class test_basic {
 public:
  test_basic() = default;
  test_basic(T data1 = DefaultData, T data2 = DefaultData,
             T data3 = DefaultData)
      : m_value{data1, data2, data3} {}
  void setValue(T value, const int index) { m_value[index] = value; }
  T getValue(const int index) { return m_value[index]; }

 private:
  T m_value[3];
};
}  // namespace Template_test

// TEST DONE
namespace StringMatch {
using ElemType = char;
constexpr int MaxSize = 50;

typedef struct SString {
  char ch[MaxSize];  // 字符串
  int length = 0;    // 字符串长度
} SString;

typedef struct HString {
  ElemType ch[MaxSize];  // 字符串
  int length;            // 字符串长度
} HString;

// 子串的定位
int index(SString S, SString T) {
  int i = 1, j = 1;
  while (i <= S.length && j <= T.length) {
    if (S.ch[i] == T.ch[j]) {  // 继续后续比较
      i++;
      j++;
    } else {  // 指针回退重新开始匹配
      i = i - j + 2;
      j = 1;
    }
  }
  if (j > T.length)
    return i - T.length;
  else
    return 0;
}

// 串的赋值
SString StrAssign(SString &T) {
  SString S;
  for (int i = 0; i < T.length; i++) {
    S.ch[i] = T.ch[i];
  }
  return S;
}
// 串的比较,如果大返回1，如果小返回-1，如果等于返回0
int StrCompare(SString S, SString T) {
  int i = 0;
  while (i < S.length && i < T.length) {
    if (S.ch[i] < T.ch[i])
      return -1;
    else if (S.ch[i] > T.ch[i])
      return 1;
    else
      i++;
  }
  if (i < S.length)
    return 1;
  else if (i < T.length)
    return -1;
  else
    return 0;
}

// 串长度
int StrLength(SString S) { return S.length; }

// 串链接,新建一个串，将两个串拼接得到新的串
SString StrConcat(SString &T, SString &S) {
  SString C;
  int i, j;
  i = j = 0;
  while (i < T.length) {
    C.ch[j] = T.ch[i];
    i++;
  }
  while (j < S.length && i < MaxSize) {
    C.ch[i] = S.ch[j];
    i++;
  }
  C.length = i;
  return C;
}

// 求子串
SString SubString(SString &S, int pos, int len) {
  SString T;
  int i;
  i = 0;
  while (i < len && pos <= S.length) {
    T.ch[i] = S.ch[pos];
    i++;
    pos++;
  }
  T.length = i;
  return T;
}

// KMP算法
void get_next(SString S, int next[]) {
  int i = 1, j = 0;
  next[0] = 0;
  next[1] = 0;
  while (i < S.length) {
    if (j == 0 || S.ch[i] == S.ch[j]) {
      ++i;
      ++j;
      next[i] = j;
    } else {
      j = next[j];
    }
  }
  // fprintf(stderr, "next: %d,%d", i, j);
}

// KMP算法改进
void get_nextval(SString S, int nextval[]) {
  int i = 1, j = 0;
  nextval[0] = 0;
  nextval[1] = 0;
  while (i < S.length) {
    if (j == 0 || S.ch[i] == S.ch[j]) {
      ++i;
      ++j;
      if (S.ch[i] != S.ch[j]) {
        nextval[i] = j;
      } else {
        nextval[i] = nextval[j];
      }
    } else {
      j = nextval[j];
    }
  }
}

int index_KMP(SString S, SString T, int next[]) {
  int i = 1, j = 1;
  while (i <= S.length && j <= T.length) {
    if (j == 0 || S.ch[i] == T.ch[j]) {  // 继续后续比较
      i++;
      j++;
    } else {
      j = next[j];
    }
  }
  if (j > T.length)
    return i - T.length;
  else
    return 0;
}
}  // namespace StringMatch

namespace SequenceBinaryTree {
using ElemType = char;
constexpr int MaxSize = 50;
constexpr char EndChar = '\0';

// 序列二叉树
typedef struct BinaryTree {
  ElemType data[MaxSize + 1];
  int BiTreeNUm;
} SqBiTree, *SqBiTreePtr;

// 二叉树的初始化
void Init_BiTree(SqBiTreePtr T) {
  T->BiTreeNUm = 1;
  for (int i = 1; i < MaxSize + 1; ++i) {
    T->data[i] = EndChar;
  }
  return;
}

// 创建二叉树
void Create_BiTree(SqBiTreePtr T, ElemType ch[]) {
  int i = 1;
  while (ch[i] != EndChar) {
    T->data[T->BiTreeNUm] = ch[i];
    T->BiTreeNUm++;
    i++;
  }
  return;
}

// 返回跟节点的数
ElemType Root_BitTree(SqBiTreePtr T) { return T->data[1]; }

// 返回二叉树节点数量
int CoutBiTree(SqBiTreePtr T) { return T->BiTreeNUm; }

// 返回二叉树深度
int DepthBiTree(SqBiTreePtr T) {
  int i = 1, j = 1;
  while (i <= T->BiTreeNUm) {
    if (T->data[i] == EndChar) {
      i = i * 2;
      j++;
    } else {
      i++;
    }
  }
  return j;
}

// 前序遍历,非递归版本
void PreOrderTraverse(SqBiTreePtr T) {
  int i = 1;
  while (i <= T->BiTreeNUm) {
    if (T->data[i] != EndChar) {
      fprintf(stderr, "%c", T->data[i]);
      i = i * 2;
    } else {
      i++;
    }
  }
  return;
}

// 前序遍历，递归版本
void PreOrderTraverseRecursive(SqBiTreePtr T, int n) {
  if (T->data[1] != EndChar) {
    fprintf(stderr, "%c", T->data[1]);
    PreOrderTraverseRecursive(T, n * 2);
    PreOrderTraverseRecursive(T, n * 2 + 1);
  }
  return;
}

// 中序遍历，非递归版本
void InOrderTraverse(SqBiTreePtr T) {
  int i = 1;
  while (i <= T->BiTreeNUm) {
    if (T->data[i] != EndChar) {
      i = i * 2;
    } else {
      fprintf(stderr, "%c", T->data[i]);
      i++;
    }
  }
  return;
}

// 中序遍历，递归版本
void InOrderTraverseRecursive(SqBiTreePtr T, int n) {
  if (T->data[1] != EndChar) {
    InOrderTraverseRecursive(T, n * 2);
    fprintf(stderr, "%c", T->data[1]);
    InOrderTraverseRecursive(T, n * 2 + 1);
  }
  return;
}

// 后序遍历，非递归版本
void PostOrderTraverse(SqBiTreePtr T) {
  int i = 1;
  while (i <= T->BiTreeNUm) {
    if (T->data[i] != EndChar) {
      i = i * 2;
    } else {
      i++;
    }
  }
  return;
}

// 后序遍历，递归版本
void PostOrderTraverseRecursive(SqBiTreePtr T, int n) {
  if (T->data[1] != EndChar) {
    PostOrderTraverseRecursive(T, n * 2);
    PostOrderTraverseRecursive(T, n * 2 + 1);
    fprintf(stderr, "%c", T->data[1]);
  }
  return;
}
// 打印二叉树,调用前序遍历
void PrintBiTree(SqBiTreePtr T) {
  PreOrderTraverse(T);
  return;
}

// 层序遍历二叉树
void LevelOrderTraverse(SqBiTreePtr T) {
  int i = 1;
  while (i <= T->BiTreeNUm) {
    fprintf(stderr, "%c", T->data[i]);
    i++;
  }
  return;
}

// 销毁二叉树内容
void DestoryBiTree(SqBiTreePtr T) {
  T->BiTreeNUm = 0;
  for (int i = 1; i < MaxSize + 1; ++i) {
    T->data[i] = EndChar;
  }
  return;
}

}  // namespace SequenceBinaryTree

namespace LinkedBinaryTree {
using ElemType = int;
constexpr int MaxSize = 50;
constexpr int Endchar = -1;

typedef struct BTNode {
  ElemType data;
  BTNode *lchild, *rchild;
} BTNode, *BTree;

// 初始化二叉树
void InitBiTree(BTree &T) { T = nullptr; }

// 生成二叉树
void CreateBiTree(BTree &T, ElemType *S) {
  int i = 0;
  InitBiTree(T);
  while (S[i] != Endchar) {
    if (T == nullptr) {
      T = (BTree)malloc(sizeof(BTNode));
      T->data = S[i];
      T->lchild = T->rchild = nullptr;
      // fprintf(stderr, "T->data = %d\n", T->data);
    } else {
      BTree p = T;
      while (p != nullptr) {
        if (S[i] < p->data) {
          if (p->lchild == nullptr) {
            p->lchild = (BTree)malloc(sizeof(BTNode));
            p->lchild->data = S[i];
            p->lchild->lchild = p->lchild->rchild = nullptr;
            // fprintf(stderr, "左子树%d:%d\n", i, p->lchild->data);
            break;
          } else {
            p = p->lchild;
            // fprintf(stderr, "进入左子树%d:\n", i);
          }
        } else {
          if (p->rchild == nullptr) {
            p->rchild = (BTree)malloc(sizeof(BTNode));
            p->rchild->data = S[i];
            p->rchild->lchild = p->rchild->rchild = nullptr;
            // fprintf(stderr, "右子树%d:%d\n", i, p->rchild->data);
            break;
          } else {
            p = p->rchild;
            // fprintf(stderr, "进入右子树%d:\n", i);
          }
        }
      }
    }
    i++;
  }
  return;
}

// 二叉树非递归前序遍历
void PreOrderTraverse(BTree &T) {
  std::stack<BTree> s;
  BTree p = T;
  while (p || !s.empty()) {
    if (p) {
      fprintf(stderr, "%d ", p->data);
      s.push(p);
      p = p->lchild;
    } else {
      p = s.top();
      s.pop();
      p = p->rchild;
    }
  }
}

// 二叉树递归前序遍历
void PreOrderTraverseRecursive(BTree &T) {
  if (T != nullptr) {
    fprintf(stderr, "%d ", T->data);
    PreOrderTraverseRecursive(T->lchild);
    PreOrderTraverseRecursive(T->rchild);
  }
  return;
}

// 二叉树非递归中序遍历
void InOrderTraverse(BTree &T) {
  std::stack<BTree> s;
  BTree p = T;
  while (p || !s.empty()) {
    if (p) {
      s.push(p);
      p = p->lchild;
    } else {
      p = s.top();
      s.pop();
      fprintf(stderr, "%d ", p->data);
      p = p->rchild;
    }
  }
}

// 二叉树递归中序遍历
void InOrderTraverseRecursive(BTree &T) {
  if (T != nullptr) {
    InOrderTraverseRecursive(T->lchild);
    fprintf(stderr, "%d ", T->data);
    InOrderTraverseRecursive(T->rchild);
  }
  return;
}

// 二叉树非递归后序遍历
void PostOrderTraverse(BTree &T) {
  std::stack<BTree> s;
  BTree p = T;
  BTree q = nullptr;
  while (p || !s.empty()) {
    if (p) {
      s.push(p);
      p = p->lchild;
    } else {
      p = s.top();
      if (p->rchild != nullptr && p->rchild != q) {
        p = p->rchild;
      } else {
        p = s.top();
        s.pop();
        fprintf(stderr, "%d ", p->data);
        q = p;
        p = nullptr;
      }
    }  // else
  }    // while
  return;
}

// 二叉树递归后序遍历
void PostOrderTraverseRecursive(BTree &T) {
  if (T != nullptr) {
    PostOrderTraverseRecursive(T->lchild);
    PostOrderTraverseRecursive(T->rchild);
    fprintf(stderr, "%d ", T->data);
  }
  return;
}

// 运用队列实现二叉树层序遍历
void LevelOrderTraverse(BTree &T) {
  std::queue<BTree> q;
  BTree p;
  q.push(T);
  while (!q.empty()) {
    p = q.front();
    q.pop();
    fprintf(stderr, "%d ", p->data);
    if (p->lchild != nullptr) {
      q.push(p->lchild);
    }  // endif
    if (p->rchild != nullptr) {
      q.push(p->rchild);
    }  // endif
  }    // while
}

// 销毁二叉树
void DestoryBiTree(BTree &T) {
  if (T == nullptr) {
    return;
  }
  DestoryBiTree(T->lchild);
  DestoryBiTree(T->rchild);
  free(T);
  T = nullptr;
  return;
}

// 根据两个整数序列，即前序遍历结果和中序遍历结果构造二叉树
BTree CreateBiTree(BTree &T, int *pre, int *in, int n) {
  if (n == 0) {
    return nullptr;
  }
  T = (BTree)malloc(sizeof(BTNode));
  T->data = pre[0];
  T->lchild = T->rchild = nullptr;
  int i = 0;
  while (in[i] != pre[0]) {
    i++;
  }
  CreateBiTree(T->lchild, pre + 1, in, i);
  CreateBiTree(T->rchild, pre + i + 1, in + i + 1, n - i - 1);
  return T;
}

// 根据两个整数序列，即后序遍历结果和中序遍历结果构造二叉树
BTree CreateBiTree2(BTree &T, int *post, int *in, int n) {
  if (n == 0) {  // 判断序列长度
    return nullptr;
  }
  T = (BTree)malloc(sizeof(BTNode));
  T->data = post[n - 1];
  T->lchild = T->rchild = nullptr;
  int i = 0;
  while (in[i] != post[n - 1]) {
    i++;
  }
  CreateBiTree2(T->lchild, post, in, i);
  CreateBiTree2(T->rchild, post + i, in + i + 1, n - i - 1);
  return T;
}

// 根据两个整数序列，即层序遍历结果和中序遍历结果构造二叉树
BTree CreateBiTree3(BTree &T, int *level, int *in, int n) {
  if (n == 0) {
    return nullptr;
  }
  // 确立根节点
  T = (BTree)malloc(sizeof(BTNode));
  T->data = level[0];
  T->lchild = T->rchild = nullptr;

  int i = 0;
  while (in[i] != level[0]) {
    i++;
  }

  ElemType left[MaxSize];
  ElemType right[MaxSize];
  int left_size = 0;
  int right_size = 0;
  for (int k = 0; k < n; k++) {    // 分离左右子树
    for (int j = 0; j < i; j++) {  // 左子树
      if (level[k] == in[j]) {     // 判断是否为左子树
        left[left_size++] = level[k];
        break;
      }
    }
    for (int j = i + 1; j < n; j++) {  // 右子树
      if (level[k] == in[j]) {         // 判断是否为右子树
        right[right_size++] = level[k];
        break;
      }
    }
  }

  CreateBiTree3(T->lchild, left, in, left_size);
  CreateBiTree3(T->rchild, right, in + i + 1, right_size);
  return T;
}
}  // namespace LinkedBinaryTree

namespace ThreadTree {
using ElemType = int;
constexpr int MaxSize = 50;
constexpr char EndFlag = '\0';
constexpr int EndFlagInt = -1;
// 线索二叉树
typedef struct ThreadNode {
  ElemType data;
  struct ThreadNode *lchild;
  struct ThreadNode *rchild;
  int ltag;
  int rtag;
} ThreadNode, *ThreadTree;

// 初始化线索二叉树
void InitThreadTree(ThreadTree &T) {
  T = nullptr;
  return;
}

// 先序递归创建二叉树
void CreateThreadTree(ThreadTree &T, ElemType *S) {
  int i = 0;
  InitThreadTree(T);
  while (S[i] != EndFlagInt) {
    if (T == nullptr) {
      T = (ThreadTree)malloc(sizeof(ThreadNode));
      T->data = S[i];
      T->lchild = T->rchild = nullptr;
      T->ltag = T->rtag = 0;
      // fprintf(stderr, "T->data = %d\n", T->data);
    } else {
      ThreadTree p = T;
      while (p != nullptr) {
        if (S[i] < p->data) {
          if (p->lchild == nullptr) {
            p->lchild = (ThreadTree)malloc(sizeof(ThreadNode));
            p->lchild->data = S[i];
            p->lchild->lchild = p->lchild->rchild = nullptr;
            p->lchild->ltag = 0;
            p->lchild->rtag = 0;
            // fprintf(stderr, "左子树%d:%d\n", i, p->lchild->data);
            break;
          } else {
            p = p->lchild;
            // fprintf(stderr, "进入左子树%d:\n", i);
          }
        } else {
          if (p->rchild == nullptr) {
            p->rchild = (ThreadTree)malloc(sizeof(ThreadNode));
            p->rchild->data = S[i];
            p->rchild->lchild = p->rchild->rchild = nullptr;
            p->rchild->ltag = 0;
            p->rchild->rtag = 0;
            // fprintf(stderr, "右子树%d:%d\n", i, p->rchild->data);
            break;
          } else {
            p = p->rchild;
            // fprintf(stderr, "进入右子树%d:\n", i);
          }
        }
      }
    }
    i++;
  }
  return;
}

void InOrderTraverse2(ThreadTree &T) {
  if (T == nullptr) {
    return;
  }
  if (T->ltag == 0) {
    InOrderTraverse2(T->lchild);
  }
  fprintf(stderr, "%d ", T->data);
  if (T->rtag == 0) {
    InOrderTraverse2(T->rchild);
  }
  return;
}

void InOrderTraverse(ThreadTree &T) {
  if (T == nullptr) {
    return;
  }
  InOrderTraverse(T->lchild);
  fprintf(stderr, "%d ", T->data);
  InOrderTraverse(T->rchild);
  return;
}
// 中序遍历线索二叉树
void InThread(ThreadTree &p, ThreadTree &pre) {
  if (p == nullptr) {
    return;
  }
  InThread(p->lchild, pre);
  if (p->lchild == nullptr) {
    p->lchild = pre;
    p->ltag = 1;
  }
  if (pre != nullptr && pre->rchild == nullptr) {
    pre->rchild = p;
    pre->rtag = 1;
  }
  pre = p;
  InThread(p->rchild, pre);
  return;
}

void CreateInThread(ThreadTree &T) {
  ThreadTree pre = nullptr;
  if (T != nullptr) {
    InThread(T, pre);
    pre->rchild = nullptr;
    pre->rtag = 1;
  }
}

}  // namespace ThreadTree
#endif  // !_BINARYTREE_H_