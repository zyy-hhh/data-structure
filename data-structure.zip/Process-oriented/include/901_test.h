//  这是针对代码的测试程序库，用于测试代码的正确性。
//  在这里，我们将测试结构体的基本功能。
#ifndef _901_TEST_H_
#define _901_TEST_H_

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <queue>
#include <random>
#include <stack>
#include <vector>

using str = std::string;
using tp = std::chrono::steady_clock::time_point;
using i64 = long long;
using u64 = unsigned long long;

// TEST FUNCTION ALL PASS DONE
namespace test_publicuse {
void test_time_stamp() {
  tp t1 = PublicUse::TimeStart();
  for (int i = 0; i < 100000; ++i) {
    PublicUse::RandomNumberGenerate(1, 10);
  }
  PublicUse::TimeEnd(t1);
  return;
}
}  // namespace test_publicuse

// TEST FUNCTION ALL PASS DONE
namespace test_LinearList {
void test_linearlist() {
  {
    fprintf(stderr, "LinearList initialed.\n");
    LinearList::SqList L;
    LinearList::InitList(L);
    fprintf(stderr, "LinearList created.\n");
    LinearList::ListAutoCreate(20, L, 1, 10, false);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList insert.\n");
    LinearList::ListInsert(L, 3, 100);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList delete.\n");
    LinearList::ListDelete(L, 4);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList find index of specific num 100.\n");
    fprintf(stderr, "%d\n", LinearList::LocateElem(L, 100));
    fprintf(stderr, "LinearList rm minest num.\n");
    LinearList::ListDeleteMin(L);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList reverse.\n");
    LinearList::Reverse(L);
    LinearList::ListOutput(L);

    fprintf(stderr, "\nLinearList Delete Function test.\n");
    fprintf(stderr, "LinearList Delete Function1 test.\n");
    LinearList::DeleteXFunction1(L, 100);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList Insert another num 60.\n");
    LinearList::ListInsert(L, 6, 50);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList Delete Function2 test.\n");
    LinearList::DeleteXFunction2(L, 50);
    LinearList::ListOutput(L);
    fprintf(stderr, "LinearList DeleteRange test.\n");
    LinearList::DeleteRangeDisorder(L, 3, 6);
    LinearList::ListOutput(L);
    fprintf(stderr, "\n\n");
  }

  {
    fprintf(stderr, "\nLinearList Ordered Function test.\n");
    fprintf(stderr, "LinearList Ordered Initial.\n");
    LinearList::SqList L_1;
    LinearList::InitList(L_1);
    fprintf(stderr, "LinearList Ordered Create.\n");
    LinearList::ListAutoCreate(10, L_1, 1, 10, true);
    LinearList::ListOutput(L_1);
    fprintf(stderr, "LinearList Ordered Insert.\n");
    LinearList::ListInsert(L_1, 3, 2);
    LinearList::ListOutput(L_1);
    fprintf(stderr, "LinearList Deleteduplicate test.\n");
    LinearList::DeleteDuplicate(L_1);
    LinearList::ListOutput(L_1);

    fprintf(stderr, "LineaerList Ordered2 Initial.\n");
    LinearList::SqList L_2;
    LinearList::InitList(L_2);
    fprintf(stderr, "LinearList Ordered2 Create.\n");
    LinearList::ListAutoCreate(10, L_2, 9, 10, true);
    LinearList::ListOutput(L_2);

    fprintf(stderr, "LinearList Merge test.\n");
    LinearList::SqList L_3;
    LinearList::InitList(L_3);
    LinearList::MergeOrder(L_1, L_2, L_3);
    LinearList::ListOutput(L_3);

    fprintf(stderr, "LinearList Reverse test.\n");
    LinearList::ReverseOrder(L_3, 0, L_3.length - 1);
    LinearList::ListOutput(L_3);
  }

  // (a1,a2,...,am,b1,b2,...,bn)->(b1,b2,...,bn,a1,a2,...,am)
  {
    fprintf(stderr, "LinearList test exchange.\n");
    LinearList::SqList L_1;
    LinearList::InitList(L_1);
    LinearList::ListAutoCreate(10, L_1, 1, 10, true);
    LinearList::ListOutput(L_1);
    fprintf(stderr, "LinearList exchange result.\n");
    LinearList::Exchange(L_1, 5, 5);
    LinearList::ListOutput(L_1);
  }
}
}  // namespace test_LinearList

// TEST FUNCTION ALL PASS DONE
namespace test_SingleLinkedList {
void test_singlelinkedlist_1() {
  fprintf(stderr, "SingleLinkedList initialed.\n");
  SingleLinkedList::LinkListAuto L_1 = new SingleLinkedList::LNodeAuto;
  fprintf(stderr, "SingleLinkedList HeadInsert created.\n");
  SingleLinkedList::ListAutoCreateTailInsert(L_1, 20, true);
  SingleLinkedList::PrintList(L_1);
  fprintf(stderr, "SingleLinkedList DeleteAllRecursive 14 test.\n");
  SingleLinkedList::DeleteAllRecursive(L_1, 14);
  SingleLinkedList::PrintList(L_1);
  fprintf(stderr, "SingleLinkedList DeleteAllRecursive2 12 test.\n");
  SingleLinkedList::DeleteAllFirst(L_1, 12);
  SingleLinkedList::PrintList(L_1);

  SingleLinkedList::LinkListAuto L_2 = new SingleLinkedList::LNodeAuto;
  fprintf(stderr, "SingleLinkedList HeadInsert created.\n");
  SingleLinkedList::ListAutoCreateTailInsert(L_2, 20, true);
  SingleLinkedList::PrintList(L_2);
  fprintf(stderr, "SingleLinkedList DeleteAllRecursive3 11 test.\n");
  SingleLinkedList::DeleteAllSecond(L_2, 11);
  SingleLinkedList::PrintList(L_2);

  fprintf(stderr, "SingleLinkedList SearchCommon Node test.\n");
  if (!SingleLinkedList::SearchCommonNodeHard(L_1, L_2)) {
    fprintf(stderr, "No common node.\n");
  }
  fprintf(stderr, "SingleLinkedList GetCommin test.\n");
  SingleLinkedList::LinkListAuto L_3 = new SingleLinkedList::LNodeAuto;
  L_3 = SingleLinkedList::GetCommon(L_1, L_2);
  SingleLinkedList::PrintList(L_3);
  if (SingleLinkedList::IsSubsequence(L_1, L_3)) {
    fprintf(stderr, "L3 is subsequence of L1.\n");
  } else {
    fprintf(stderr, "L3 is not subsequence of L1.\n");
  }

  fprintf(stderr, "SingleLinkedList Merge Ascend test.\n");
  SingleLinkedList::MergeListAscend(L_1, L_2);
  SingleLinkedList::DeleteRepeat(L_1);
  SingleLinkedList::PrintList(L_1);
  fprintf(stderr, "SingleLinkedList Merge Descend test.\n");
  SingleLinkedList::MergeListDescend(L_1, L_3);
  SingleLinkedList::DeleteRepeat(L_1);
  SingleLinkedList::PrintList(L_1);
}

void test_singlelinkedlist_2() {
  SingleLinkedList::LinkListAuto L_3 = new SingleLinkedList::LNodeAuto;
  fprintf(stderr, "SingleLinkedList HeadInsert created.\n");
  SingleLinkedList::ListAutoCreateHeadInsert(L_3, 20, false);
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList length:\t %d \n",
          SingleLinkedList::ListLength(L_3));
  fprintf(stderr, "SingleLinkedList Element Search 4th:\t %d \n",
          SingleLinkedList::GetElem(L_3, 4)->data);

  fprintf(stderr, "SingleLinkedList InsertHead test.\nBefore:\n");
  SingleLinkedList::PrintList(L_3);
  SingleLinkedList::ListInsertAhead(L_3, -1, 6);
  fprintf(stderr, "After:\n");
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList InsertAhead Location\t %d \n",
          SingleLinkedList::LocateElem(L_3, -1)->data);
  SearchAndDelete(L_3, -1);
  SingleLinkedList::PrintList(L_3);

  fprintf(stderr, "SingleLinkedList InsertBehind test.\nBefore:\n");
  SingleLinkedList::PrintList(L_3);
  SingleLinkedList::ListInsertBehind(L_3, -2, 10);
  fprintf(stderr, "After:\n");
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList InsertAhead Location\t %d \n",
          SingleLinkedList::LocateElem(L_3, -2)->data);
  fprintf(stderr, "SingleLinkedList Delete given index test.\n");
  SingleLinkedList::ListDelete(L_3, 4);
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList Print Reverse test.\n");
  if (!SingleLinkedList::ListEmpty(L_3)) {
    SingleLinkedList::PrintListReverse(L_3->next);
  }
  fprintf(stderr, "\nSingleLinkedList Rm Min test.\n");
  SingleLinkedList::SearchAndDeleteMin(L_3);
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList Reverse test.\n");
  SingleLinkedList::ReverseListFirst(L_3);
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList Reverse2 test.\n");
  SingleLinkedList::ReverseListFirst(L_3);
  SingleLinkedList::PrintList(L_3);
  fprintf(stderr, "SingleLinkedList Delete from minest test.\n");
  SingleLinkedList::MinDelete(L_3);

  SingleLinkedList::LinkListAuto L_4 = new SingleLinkedList::LNodeAuto;
  fprintf(stderr, "SingleLinkedList Insert created.\n");
  SingleLinkedList::ListAutoCreateTailInsert(L_4, 10, false);
  SingleLinkedList::PrintList(L_4);
  fprintf(stderr, "SingleLinkedList SoarList test.\n");
  SingleLinkedList::SoarList(L_4);
  SingleLinkedList::PrintList(L_4);
  fprintf(stderr, "SingleLinkedList Detach test.\n");
  SingleLinkedList::LinkListAuto L_5 = SingleLinkedList::DisCreate(L_4);
  fprintf(stderr, "SingleLinkedList Detach List1.\n");
  SingleLinkedList::PrintList(L_4);
  fprintf(stderr, "SingleLinkedList Detach List2.\n");
  SingleLinkedList::PrintList(L_5);

  fprintf(stderr, "SingleLinkedList Detach2 created.\n");
  SingleLinkedList::LinkListAuto L_6 = SingleLinkedList::DisCreate2(L_4);
  fprintf(stderr, "SingleLinkedList Detach2 List1.\n");
  SingleLinkedList::PrintList(L_4);
  fprintf(stderr, "SingleLinkedList Detach2 List2.\n");
  SingleLinkedList::PrintList(L_6);
}
}  // namespace test_SingleLinkedList

// TEST FUNCTION ALL PASS DONE
namespace test_DoubleLinkedList {
void test_DoubleLinkedList_1() {
  fprintf(stderr, "DoubleLinkedList initialed.\n");
  DoubleLinkedList::DLinkList L_1;
  DoubleLinkedList::InitList(L_1);
  fprintf(stderr, "DoubleLinkedList HeadInsert created.\n");
  DoubleLinkedList::ListInsertHead(L_1, 20);
  DoubleLinkedList::ListInsertHead(L_1, 30);
  DoubleLinkedList::ListDisplay(L_1);
  fprintf(stderr, "DoubleLinkedList is Empty:\t %d \n",
          DoubleLinkedList::ListEmpty(L_1));
  fprintf(stderr, "DoubleLinkedList TailInsert test.\n");
  DoubleLinkedList::ListInsertTail(L_1, 14);
  DoubleLinkedList::ListInsertTail(L_1, 15);
  DoubleLinkedList::ListDisplay(L_1);
  fprintf(stderr, "DoubleLinkedList GetHead test.\n");
  fprintf(stderr, "DoubleLinkedList GetHead:\t %d \n",
          DoubleLinkedList::ListGetHead(L_1));
  fprintf(stderr, "DoubleLinkedList GetElement test.\n");
  fprintf(stderr, "DoubleLinkedList GetElement:\t %d \n",
          DoubleLinkedList::ListGetElement(L_1, 3));
  fprintf(stderr, "DoubleLinkedList Delete test.\n");
  DoubleLinkedList::ListDelete(L_1, 3);
  DoubleLinkedList::ListDisplay(L_1);
  fprintf(stderr, "DoubleLinkedList GetLength test: \t %d \n",
          DoubleLinkedList::ListLength(L_1));
}

void test_DoubleLinkedList_2() {
  fprintf(stderr, "DoubleLinkedList AutoInit created.\n");
  DoubleLinkedList::DFLinkList L_2;
  DoubleLinkedList::ListAutoInit(L_2, 10);
  DoubleLinkedList::ListDisplay(L_2);
  DoubleLinkedList::ListInsertSort(L_2, 3);
  DoubleLinkedList::ListDisplay(L_2);
}
}  // namespace test_DoubleLinkedList

// TEST FUNCTION ALL PASS DONE
namespace test_CircularSingleLinkedList {
void test_CircularSingleLinkedList_1() {
  CircularSingleLinkedList::CLinkList L_1;  // 初始化
  CircularSingleLinkedList::InitList(L_1);  // 初始化
  fprintf(stderr, "CircularSingleLinkedList is Empty?\t %s \n",
          CircularSingleLinkedList::ListEmpty(L_1) ? "yes" : "no");
  fprintf(stderr, "CircularSingleLinkedList HeadInsert created.\n");
  CircularSingleLinkedList::ListInsertHead(L_1, 10);  // 头插
  CircularSingleLinkedList::ListInsertHead(L_1, 20);  // 头插
  CircularSingleLinkedList::ListDisplay(L_1);         // 显示
  fprintf(stderr, "CircularSingleLinkedList TailInsert created.\n");
  CircularSingleLinkedList::ListInsertTail(L_1, 30);  // 尾插
  CircularSingleLinkedList::ListInsertTail(L_1, 40);  // 尾插
  CircularSingleLinkedList::ListDisplay(L_1);         // 显示
  fprintf(stderr, "CircularSingleLinkedList GetHead test:\t %d \n",
          CircularSingleLinkedList::ListGetHead(L_1));
  fprintf(stderr, "CircularSingleLinkedList GetElement test:\t %d \n",
          CircularSingleLinkedList::ListGetElement(L_1, 3));
  fprintf(stderr, "CircularSingleLinkedList Delete test.\n");
  CircularSingleLinkedList::ListDelete(L_1, 3);  // 删除第三个元素
  CircularSingleLinkedList::ListDisplay(L_1);    // 显示
  fprintf(stderr, "CircularSingleLinkedList ListCombine test\n");
  CircularSingleLinkedList::CLinkList L_2;
  CircularSingleLinkedList::InitList(L_2);
  CircularSingleLinkedList::ListInsertHead(L_2, 11);
  CircularSingleLinkedList::ListInsertHead(L_2, 21);
  CircularSingleLinkedList::ListDisplay(L_2);
  CircularSingleLinkedList::ListLink(L_1, L_2);
  CircularSingleLinkedList::ListDisplay(L_1);  // 包含头节点的链表
  fprintf(stderr, "CircularSingleLinkedList ListDeleteMin test\n");
  CircularSingleLinkedList::ListDisplay(L_1);
  CircularSingleLinkedList::ListDeleteMin(L_1);
}
}  // namespace test_CircularSingleLinkedList

// TEST FUNCTION ALL PASS DONE
namespace test_CircularDoubleLinkedList {
void test_CircularDoubleLinkedList_1() {
  CircularDoubleLinkedList::CDLinkList L_1;
  fprintf(stderr, "CircularDoubleLinkedList initialed.\n");
  CircularDoubleLinkedList::InitList(L_1);
  fprintf(stderr, "CircularDoubleLinkedList List Is empty?\t %s \n",
          CircularDoubleLinkedList::ListEmpty(L_1) ? "yes" : "no");
  fprintf(stderr, "CircularDoubleLinkedList HeadInsert created.\n");
  CircularDoubleLinkedList::ListInsertHead(L_1, 10);
  CircularDoubleLinkedList::ListInsertHead(L_1, 20);
  CircularDoubleLinkedList::ListDisplay(L_1);
  fprintf(stderr, "CircularDoubleLinkedList TailInsert created.\n");
  CircularDoubleLinkedList::ListInsertTail(L_1, 30);
  CircularDoubleLinkedList::ListInsertTail(L_1, 40);
  fprintf(stderr, "CircularDoubleLinkedList ListDisplay test:");
  CircularDoubleLinkedList::ListDisplay(L_1);
  fprintf(stderr, "CircularDoubleLinkedList ListDisplayReverse test:");
  CircularDoubleLinkedList::ListDisplayReverse(L_1);
  fprintf(stderr, "CircularDoubleLinkedList GetHead test:\t %d \n",
          CircularDoubleLinkedList::ListGetHead(L_1));
  fprintf(stderr, "CircularDoubleLinkedList GetElement test:\t %d \n",
          CircularDoubleLinkedList::ListGetElement(L_1, 2));
  fprintf(stderr, "CircularDoubleLinkedList Delete test:");
  CircularDoubleLinkedList::ListDelete(L_1, 2);
  CircularDoubleLinkedList::ListDisplay(L_1);
  fprintf(stderr, "CircularDoubleLinkedList GetLength test: \t %d \n",
          CircularDoubleLinkedList::ListLength(L_1));
  fprintf(stderr, "CircularDoubleLinkedList ListIsSymmetry test: \t %s \n",
          CircularDoubleLinkedList::ListIsSymmetry(L_1) ? "yes" : "no");
  CircularDoubleLinkedList::ListInsertTail(L_1, 40);
  CircularDoubleLinkedList::ListInsertTail(L_1, 30);
  CircularDoubleLinkedList::ListInsertTail(L_1, 20);
  fprintf(stderr, "CircularDoubleLinkedList ListIsSymmetry test: \t %s \n",
          CircularDoubleLinkedList::ListIsSymmetry(L_1) ? "yes" : "no");
}
}  // namespace test_CircularDoubleLinkedList

// TEST FUNCTION ALL PASS DONE
namespace test_SqStack {
void test_SqStack_1() {
  SqStack::SqStack S;
  SqStack::ElemType e;
  fprintf(stderr, "test_SqStack initialed.\n");
  SqStack::InitStack(S);
  fprintf(stderr, "test SqStack IsEmpty?\t %s \n",
          SqStack::StackEmpty(S) ? "yes" : "no");
  fprintf(stderr, "test SqStack Push test.\n");
  SqStack::Push(S, 1);
  SqStack::Push(S, 2);
  fprintf(stderr, "test SqStack IsEmpty?\t %s \n",
          SqStack::StackEmpty(S) ? "yes" : "no");
  fprintf(stderr, "test SqStack display test.");
  SqStack::StackDisplay(S);
  fprintf(stderr, "test SqStack GetTop Element test:\t %d \n",
          SqStack::GetTop(S, e) ? e : -1);
  SqStack::Push(S, 5);
  fprintf(stderr, "test SqStack get length test:\t %d \n",
          SqStack::StackLength(S));
  fprintf(stderr, "test SqStack Pop test and the top data : %d \n",
          SqStack::Pop(S, e) ? e : -1);
}

void test_SqStack_2() {
  SqStack::SqShareStack S;
  SqStack::ElemType e;
  fprintf(stderr, "test SqShareStack initialed.\n");
  SqStack::init(S);
  fprintf(stderr, "test SqShareStack Insert test.\n");
  SqStack::push(S, 1, 0);
  SqStack::push(S, 2, 1);
  SqStack::push(S, 3, 0);
  SqStack::push(S, 4, 1);
  fprintf(stderr, "test SqShareStack display test.\n");
  SqStack::display(S, 0);
  SqStack::display(S, 1);
  fprintf(stderr, "test SqShareStack Pop test\n");
  SqStack::pop(S, e, 0);
  SqStack::pop(S, e, 1);
  SqStack::display(S, 0);
  SqStack::display(S, 1);
}
}  // namespace test_SqStack

// TEST FUNCTION ALL PASS DONE
namespace test_LinkStack {
void test_LinkStack_1() {
  LinkStack::LinkStack S;
  LinkStack::ElemType e;
  fprintf(stderr, "test_LinkStack initialed.\n");
  LinkStack::InitStack(S);
  fprintf(stderr, "test LinkStack IsEmpty?\t %s \n",
          LinkStack::StackEmpty(S) ? "yes" : "no");
  fprintf(stderr, "test LinkStack Push test.\n");
  LinkStack::Push(S, 1);
  LinkStack::Push(S, 2);
  fprintf(stderr, "test LinkStack IsEmpty?\t %s \n",
          LinkStack::StackEmpty(S) ? "yes" : "no");
  fprintf(stderr, "test LinkStack display test.");
  LinkStack::Display(S);
  fprintf(stderr, "test LinkStack GetTop Element test:\t %d \n",
          LinkStack::GetTop(S, e) ? e : -1);
  LinkStack::Push(S, 5);
  fprintf(stderr, "test LinkStack get length test:\t %d \n",
          LinkStack::StackLength(S));
  fprintf(stderr, "test LinkStack Pop test and the top data : %d \n",
          LinkStack::Pop(S, e) ? e : -1);
  LinkStack::Push(S, 5);
  LinkStack::Push(S, 4);
  LinkStack::Push(S, 2);
  LinkStack::Push(S, 1);
  int length = LinkStack::StackLength(S);
  fprintf(stderr, "test LinkStack get length test:\t %d \n", length);
  fprintf(stderr, "test LinkStack is Symmetrical?\t %s \n",
          LinkStack::IsSymmetrical(S, length) ? "yes" : "no");
}

void test_LinkStack_2() {
  LinkStack::LinkStack L_1, L_2;
  LinkStack::ElemType e;
  LinkStack::InitQueue(L_1, L_2);
  LinkStack::EnQueue(L_1, L_2, 1);
  LinkStack::EnQueue(L_1, L_2, 2);
  LinkStack::EnQueue(L_1, L_2, 3);
  fprintf(stderr, "test LinkStack Dequeue test1:\t %d \n",
          LinkStack::DeQueue(L_1, L_2, e) ? e : -1);
  fprintf(stderr, "test LinkStack Dequeue test2:\t %d \n",
          LinkStack::DeQueue(L_1, L_2, e) ? e : -1);
  fprintf(stderr, "test LinkStack Dequeue test3:\t %d \n",
          LinkStack::DeQueue(L_1, L_2, e) ? e : -1);
}

void test_LinkStack_3() {
  char string[] = "([{}])";
  char string2[] = "{([(])})";
  fprintf(stderr, "test BracketsCheck:\t %s \n",
          LinkStack::Match(string) ? "success" : "fail");
  fprintf(stderr, "test BracketsCheck2:\t %s \n",
          LinkStack::Match(string2) ? "success" : "fail");
}
}  // namespace test_LinkStack

// TEST FUNCTION ALL PASS DONE
namespace test_SQueue {
void test_SQueue() {
  SQueue::SqQueue Q;
  SQueue::ElemType e;
  fprintf(stderr, "test SqQueue initialed.\n");
  SQueue::InitQueue(Q);
  fprintf(stderr, "test SqQueue IsEmpty?\t %s \n",
          SQueue::QueueEmpty(Q) ? "yes" : "no");
  fprintf(stderr, "test SqQueue EnQueue test.\n");
  SQueue::EnQueue(Q, 1);
  SQueue::EnQueue(Q, 2);
  fprintf(stderr, "test SqQueue IsEmpty?\t %s \n",
          SQueue::QueueEmpty(Q) ? "yes" : "no");
  fprintf(stderr, "test SqQueue display test.");
  SQueue::QueueDisplay(Q);
  fprintf(stderr, "test SqQueue GetFront Element test:\t %d \n",
          SQueue::GetHead(Q, e) ? e : -1);
  SQueue::EnQueue(Q, 5);
  fprintf(stderr, "test SqQueue DeQueue test and the front data : %d \n",
          SQueue::DeQueue(Q, e) ? e : -1);
}

void test_SqRQueue() {
  SQueue::SqRQueue Q;
  SQueue::ElemType e;
  fprintf(stderr, "test SqRQueue initialed.\n");
  SQueue::InitQueueRecursive(Q);
  fprintf(stderr, "test SqRQueue IsEmpty?\t %s \n",
          SQueue::QueueEmptyRecursive(Q) ? "yes" : "no");
  fprintf(stderr, "test SqRQueue EnQueue test.\n");
  SQueue::EnQueueRecursive(Q, 1);
  SQueue::EnQueueRecursive(Q, 2);
  fprintf(stderr, "test SqRQueue IsEmpty?\t %s \n",
          SQueue::QueueEmptyRecursive(Q) ? "yes" : "no");
  fprintf(stderr, "test SqRQueue display test.");
  SQueue::QueueDisplayRecursive(Q);
  fprintf(stderr, "test SqRQueue DeQueue test and the front data : %d \n",
          SQueue::DeQueueRecursive(Q, e) ? e : -1);
}
}  // namespace test_SQueue

// TEST FUNCTION ALL PASS DONE
namespace test_LinkQueue {
void test_LinkQueue_1() {
  LinkQueue::LinkQueue Q;
  LinkQueue::ElemType e;
  fprintf(stderr, "test LinkQueue initialed.\n");
  LinkQueue::initLinkQueue(Q);
  fprintf(stderr, "test LinkQueue IsEmpty?\t %s \n",
          LinkQueue::isLinkQueueEmpty(Q) ? "yes" : "no");
  fprintf(stderr, "test LinkQueue EnQueue test.\n");
  LinkQueue::enLinkQueue(Q, 1);
  LinkQueue::enLinkQueue(Q, 3);
  LinkQueue::displayLinkQueue(Q);
  fprintf(stderr, "test LinkQueue Pop head element test:\t %d \n",
          LinkQueue::deLinkQueue(Q, e) ? e : -1);
  LinkQueue::displayLinkQueue(Q);
}

void test_LinkQueue_2() {}
}  // namespace test_LinkQueue

// TEST FUNCTION ALL PASS DONE
namespace test_Template {
void test_Template_1() {
  Template_test::test_basic<int> basic{1, 2, 3};
  basic.setValue(10, 1);
  fprintf(stderr, "basic.getValue1() = %d\n", basic.getValue(1));
}
}  // namespace test_Template

// TEST FUNCTION ALL PASS DONE
namespace test_StringMatch {
void test_StringMatch_1() {
  StringMatch::SString T, S;
  str main_str = "aaabcacbbbaa";
  for (int i = 1; i < int(main_str.length() + 1); i++) {
    T.ch[i] = main_str[i - 1];
    T.length++;
  }
  str sub_str = "abcac";
  for (int i = 1; i < int(sub_str.size() + 1); i++) {
    S.ch[i] = sub_str[i - 1];
    S.length++;
  }
  fprintf(stderr, "test StringMatch_1:\t %d \n", StringMatch::index(T, S));
  int next[sub_str.length() + 1];
  fprintf(stderr, "test string get next array:\n");
  StringMatch::get_next(S, next);
  for (int i = 1; i < int(sub_str.length() + 1); i++) {
    fprintf(stderr, "next[%d] = %d\n", i, next[i]);
  }
  fprintf(stderr, "test string get nextval array:\n");
  int nextval[sub_str.length() + 1];
  StringMatch::get_nextval(S, nextval);
  for (int i = 1; i < int(sub_str.length() + 1); i++) {
    fprintf(stderr, "nextval[%d] = %d\n", i, nextval[i]);
  }
  fprintf(stderr, "test index KMP:\t %d \n",
          StringMatch::index_KMP(T, S, next));
  fprintf(stderr, "test index KMP:\t %d \n",
          StringMatch::index_KMP(T, S, nextval));
}

}  // namespace test_StringMatch

namespace test_SqBiTree {
void test_SqBiTree_1() { return; }
}  // namespace test_SqBiTree

namespace test_LinkBiTree {
void test_LinkBiTree_1() {
  LinkedBinaryTree::BTree T;        // 初始化二叉树
  LinkedBinaryTree::InitBiTree(T);  // 初始化二叉树
  int str[] = {1, 5, 9, 3, 0, 6, 8, 2, 7, 4, -1};
  LinkedBinaryTree::CreateBiTree(T, str);
  fprintf(stderr, "无递归先序遍历:");
  LinkedBinaryTree::PreOrderTraverse(T);
  fprintf(stderr, "\n  递归先序遍历:");
  LinkedBinaryTree::PreOrderTraverseRecursive(T);
  fprintf(stderr, "\n无递归中序遍历:");
  LinkedBinaryTree::InOrderTraverse(T);
  fprintf(stderr, "\n  递归中序遍历:");
  LinkedBinaryTree::InOrderTraverseRecursive(T);
  fprintf(stderr, "\n无递归后序遍历:");
  LinkedBinaryTree::PostOrderTraverse(T);
  fprintf(stderr, "\n  递归后序遍历:");
  LinkedBinaryTree::PostOrderTraverseRecursive(T);
  fprintf(stderr, "\n      层序遍历:");
  LinkedBinaryTree::LevelOrderTraverse(T);
  int pre[] = {1, 0, 5, 3, 2, 4, 9, 6, 8, 7};
  int in[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
  int post[] = {0, 2, 4, 3, 7, 8, 6, 9, 5, 1};
  int level[] = {1, 0, 5, 3, 9, 2, 4, 6, 8, 7};
  LinkedBinaryTree::BTree S;
  fprintf(stderr, "\n利用先序和中序数组重建二叉树:");
  LinkedBinaryTree::CreateBiTree(S, pre, in, 10);
  fprintf(stderr, "\n利用后序遍历进行验证:");
  LinkedBinaryTree::PostOrderTraverse(S);
  LinkedBinaryTree::DestoryBiTree(S);
  fprintf(stderr, "\n利用后序和中序数组重建二叉树:");
  LinkedBinaryTree::CreateBiTree2(S, post, in, 10);
  fprintf(stderr, "\n利用先序遍历进行验证:");
  LinkedBinaryTree::PreOrderTraverse(S);
  LinkedBinaryTree::DestoryBiTree(S);
  fprintf(stderr, "\n利用层序遍历和中序遍历重建二叉树:");
  LinkedBinaryTree::CreateBiTree3(S, level, in, 10);
  fprintf(stderr, "\n利用先序遍历进行验证:");
  LinkedBinaryTree::PreOrderTraverse(S);
  LinkedBinaryTree::DestoryBiTree(S);
}
}  // namespace test_LinkBiTree

namespace test_ThreadTree {
void test_TheadTree_1() {
  ThreadTree::ThreadTree T;
  //   char input[] = "ABRFIJLNE";
  int input_num[] = {1, 2, 3, 4, 5, 6, 7, 8, 9, -1};
  ThreadTree::CreateThreadTree(T, input_num);
  ThreadTree::InOrderTraverse(T);
  fprintf(stderr, "\ntest2\n");
  ThreadTree::CreateInThread(T);
  ThreadTree::InOrderTraverse2(T);
}
}  // namespace test_ThreadTree
#endif  // _901_TEST_H_