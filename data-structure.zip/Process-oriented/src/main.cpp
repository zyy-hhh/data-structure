#include "901.h"
#include "901_test.h"

int main() {
  // test_publicuse::test_time_stamp();
  // test_LinearList::test_linearlist();
  // test_SingleLinkedList::test_singlelinkedlist_1();
  // test_DoubleLinkedList::test_DoubleLinkedList_2();
  // test_CircularSingleLinkedList::test_CircularSingleLinkedList_1();
  // test_CircularDoubleLinkedList::test_CircularDoubleLinkedList_1();
  // test_StaticLinkedList::test_StaticLinkedList_1();
  // test_Template::test_Template_1();
  // test_SqStack::test_SqStack_2();
  //   test_LinkStack::test_LinkStack_1();
  // test_SQueue::test_SqRQueue();
  // test_LinkQueue::test_LinkQueue_1();
  // test_LinkStack::test_LinkStack_3();
  // test_StringMatch::test_StringMatch_1();
  test_LinkBiTree::test_LinkBiTree_1();
  // test_ThreadTree::test_TheadTree_1();
  return 0;
}