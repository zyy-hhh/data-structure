#ifndef _901_H_
#define _901_H_

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>

#include <iostream>
#include <queue>
#include <random>
#include <stack>
#include <vector>

namespace PublicUse{
    using rd = std::random_device;
    using mt = std::mt19937 ;
    using tp = std::chrono::steady_clock::time_point;

    class TimeCounter{
        public:
            TimeCounter();
            ~TimeCounter();
            void start();
            void stop();
            void reset();
            void print();
        private:
            tp start_time;
            tp stop_time;
            float total_time;
    };

    int RandomGenerator(int min, int max);
}
#endif