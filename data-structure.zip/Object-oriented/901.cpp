#include "901.h"

PublicUse::TimeCounter::TimeCounter(){
    start_time = stop_time = std::chrono::steady_clock::now();
    total_time = 0;
}

PublicUse::TimeCounter::~TimeCounter(){
    stop_time = std::chrono::steady_clock::now();
    total_time = std::chrono::duration_cast<std::chrono::duration<float>>(stop_time - start_time).count();
}

PublicUse::RandomGenerator(int min, int max){
    rd rd;
    mt mt(rd());
    std::uniform_int_distribution<int> dist(min, max);
    return dist(mt);
}