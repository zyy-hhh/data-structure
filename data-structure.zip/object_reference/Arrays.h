#pragma once

template <class T>
class Arrays {
 public:
  Arrays(){};
  Arrays(int, const int v = 0);
  Arrays(const Arrays<T>&);
  ~Arrays();

  T& operator[](int);
  T& operator[](int) const;
  void print();

  // 基础函数
  int getSize();
  void setSize(int);
  T* getStartPrt();
  T* getLastPrt();
  void setStartPrt(T);
  void setLastPrt(T);
  void setValue(int, T);
  void setArrays(T* arr) { this->array = arr; }

  // 虚拟函数
  virtual void push(T) = 0;
  virtual void pop() = 0;

 private:
  // 模版数组的容量
  T* start = nullptr;  // 数组的起始指针
  T* last = nullptr;   // 数组的末尾指针
  int size = 0;        // 数组的大小
  T* array;            // 模版数组
};

// 根据数组大小初始化数组
template <class T>
Arrays<T>::Arrays(int size, const int beginValue) {
  // 创建数组
  array = new T[size * 2 + 1]{beginValue};
  // 获取数组首元素
  start = &array[0];
  // 获取数组末元素
  last = &array[size - 1];
  // 设置数组大小
  this->size = size;
}

// 根据数组指针进行数组的拷贝
template <class T>
Arrays<T>::Arrays(const Arrays<T>& arr) {
  // 创建数组
  array = new T[arr.size * 2 + 1];
  // 获取数组首元素
  start = &array[0];
  // 获取数组末元素
  last = &array[arr.size - 1];
  // 设置数组大小
  this->size = arr.size;
  // 设置数组值
  for (int i = 0; i < size; i++) {
    array[i] = arr[i];
  }
}

// 析构函数：删除数组
template <class T>
Arrays<T>::~Arrays() {
  delete[] array;
}

// 打印数组元素
template <class T>
void Arrays<T>::print() {
  for (int i = 0; i < size; i++) {
    fprintf(stderr, "%d ", array[i]);
  }
  fprintf(stderr, "\n");
}

// 获取数组对应下标的元素
template <class T>
T& Arrays<T>::operator[](int index) {
  return array[index];
}

// 获取数组对应下标的元素（const）
template <class T>
T& Arrays<T>::operator[](int index) const {
  return array[index];
}

// 修改对应数组下标的元素
template <class T>
void Arrays<T>::setValue(int index, T value) {
  array[index] = value;
}

// 获取数组大小
template <class T>
int Arrays<T>::getSize() {
  return this->size;
}

// 设置数组大小
template <class T>
void Arrays<T>::setSize(int size) {
  this->size = size;
}

// 获取数组首元素指针
template <class T>
T* Arrays<T>::getStartPrt() {
  return this->start;
}

// 设置数组首元素指针
template <class T>
void Arrays<T>::setStartPrt(T addr) {
  this->start = &addr;
}

// 设置数组末元素指针
template <class T>
void Arrays<T>::setLastPrt(T addr) {
  this->last = &addr;
}

// 获取数组末元素指针
template <class T>
T* Arrays<T>::getLastPrt() {
  return this->last;
}
