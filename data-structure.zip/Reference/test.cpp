#include <algorithm>
#include <cstring>
#include <iostream>
#include <vector>
using namespace std;

int dp[100][100];

int main() {
  int a = -3 / 2;
  a = -3 >> 1;
  int i = 16777217;
  float f = i;
  cout << f << endl;
  unsigned int *p = (unsigned int *)&f;
  cout << *p << endl;
  cout << (int)(float)i << endl;

  return 0;
}
