#include <stdio.h>

#include <cmath>
#include <iostream>
#include <queue>
#include <stack>
#include <vector>

using namespace std;

/// 树 start

// 二叉树链表
namespace BTTree {
// 结构定义
typedef struct BTNode {
  int data;
  struct BTNode *left, *right;
} BTNode;

// 插入
// return 1 - 插入成功
//        0 - 未找到src
int insertBTNode(BTNode *tree, int src, int x, bool isleft) {
  if (tree) {
    if (tree->data == src) {
      BTNode *t = (BTNode *)malloc(sizeof(BTNode));
      t->data = x;
      t->left = t->right = NULL;
      if (isleft) {
        tree->left = t;
      } else {
        tree->right = t;
      }
      return 1;
    } else {
      if (!insertBTNode(tree->left, src, x, isleft)) {
        return insertBTNode(tree->right, src, x, isleft);
      } else {
        return 1;
      }
    }
  } else {
    return 0;
  }
}

void freeTree(BTNode *tree) {
  if (tree) {
    if (tree->left) {
      freeTree(tree->left);
    }
    if (tree->right) {
      freeTree(tree->right);
    }
    free(tree);
  }
}

// 宽度遍历 或者说是层次遍历
void BFS(BTNode *tree) {
  if (!tree) return;
  queue<BTNode *> q;
  BTNode *t;
  q.push(tree);
  while (!q.empty()) {
    t = q.front();
    q.pop();
    cout << t->data << " ";
    if (t->left) q.push(t->left);
    if (t->right) q.push(t->right);
  }
  return;
}

// 深度遍历 递归形式 没啥意义？
void DFS(BTNode *tree) {
  if (!tree) return;
  cout << tree->data << " ";
  if (tree->left) DFS(tree->left);
  if (tree->right) DFS(tree->right);
}

// 先序遍历 递归形式
void PreOrder(BTNode *tree) {
  if (!tree) return;
  cout << tree->data << endl;
  PreOrder(tree->left);
  PreOrder(tree->right);
}

// 中序遍历 递归形式
void InOrder(BTNode *tree) {
  if (!tree) return;
  InOrder(tree->left);
  cout << tree->data << endl;
  InOrder(tree->right);
}

// 后序遍历 递归形式
void PostOrder(BTNode *tree) {
  if (!tree) return;
  PostOrder(tree->left);
  PostOrder(tree->right);
  cout << tree->data << endl;
}

// 求深度 递归形式
int DepthTree(BTNode *tree) {
  if (!tree) return 0;
  return max(DepthTree(tree->left), DepthTree(tree->right)) + 1;
}

// 求深度 非递归形式
int DepthTree2(BTNode *tree) {
  if (!tree) return 0;
  int dep = 0;
  BTNode *t;
  queue<BTNode *> q;
  q.push(tree);
  while (!q.empty()) {
    ++dep;
    for (int i = 0; i < q.size(); ++i) {
      t = q.front();
      q.pop();
      if (t->left) q.push(t->left);
      if (t->right) q.push(t->right);
    }
  }
  return dep;
}

// 求宽度
int WidthTree(BTNode *tree) {
  if (!tree) return 0;
  int width = 0;
  BTNode *t;
  queue<BTNode *> q;
  q.push(tree);
  while (!q.empty()) {
    width = max(width, (int)q.size());
    for (int i = 0; i < q.size(); ++i) {
      t = q.front();
      q.pop();
      if (t->left) q.push(t->left);
      if (t->right) q.push(t->right);
    }
  }
  return width;
}

// 二叉排序树插入
// return 1 - 插入成功
//        0 - 插入失败
int InsertBSTree(BTNode *&tree, int x) {
  if (!tree) {
    tree = (BTNode *)malloc(sizeof(BTNode));
    tree->data = x;
    tree->left = tree->right = NULL;
    return 1;
  } else {
    if (x < tree->data) {
      return InsertBSTree(tree->left, x);
    } else if (x > tree->data) {
      return InsertBSTree(tree->right, x);
    } else {
      // 相等，不用插入
      return 0;
    }
  }
}

// 排序二叉树查找 递归形式
BTNode *SearchBSTree(BTNode *tree, int x) {
  if (!tree) return NULL;
  if (tree->data == x)
    return tree;
  else if (tree->data > x)
    return SearchBSTree(tree->left, x);
  else
    return SearchBSTree(tree->right, x);
}

// 排序二叉树查找 非递归形式
BTNode *SearchBSTree2(BTNode *tree, int x) {
  BTNode *p = tree;
  while (p) {
    if (p->data < x) {
      p = p->right;
    } else if (p->data > x) {
      p = p->left;
    } else {
      break;
    }
  }
  return p;
}

// todo: 顺序表形式的二叉树

}  // namespace BTTree

namespace Map {
// 邻接矩阵
typedef struct MGraph {
  int vex[100];
  int edge[100][100];
  int vexnum;
} MGraph;

// 邻接表
typedef struct ArcNode {
  int adjvex;
  int data;  // 权重
  struct ArcNode *next;
} ArcNode;
typedef struct ALNode {
  int data;
  int inCount;  // 入度
  struct ArcNode *first;
} ALNode;
typedef struct ALGraph {
  ALNode *vex[100];
  int vexnum;
} ALGraph;

// 初始化邻接表
void InitALGraph(ALGraph *g) {
  if (!g) return;
  g->vexnum = 0;
  for (int i = 0; i < 100; ++i) {
    g->vex[i] = NULL;
  }
}

// 释放空间
void FreeALGraph(ALGraph *g) {
  if (!g) return;
  for (int i = 0; i < 100; ++i) {
    if (g->vex[i]) {
      ALNode *p = g->vex[i];

      // 释放边
      ArcNode *q;
      while (p->first) {
        q = p->first;
        p->first = q->next;
        free(q);
      }

      // 释放点
      free(p);
      g->vex[i] = NULL;
    }
  }
}

// 邻接表插入点
// return 1 - 成功
// return 0 - 失败
int InsertVex(ALGraph *g, int index, int val) {
  if (!g) return 0;
  if (g->vex[index] == NULL) {
    g->vex[index] = (ALNode *)malloc(sizeof(ALNode));
    g->vex[index]->data = val;
    g->vex[index]->inCount = 0;
    g->vex[index]->first = NULL;
    ++g->vexnum;
    return 1;
  } else {
    return 0;
  }
}

// 邻接表插入边
// return 1 - 成功
//        0 - 失败
int InsertEdge(ALGraph *g, int src, int dst, int val) {
  if (!g) return 0;
  if (g->vex[src] == NULL) return 0;
  if (g->vex[dst] == NULL) return 0;
  ArcNode *p = (ArcNode *)malloc(sizeof(ArcNode));
  p->adjvex = dst;
  p->data = val;
  p->next = g->vex[src]->first;
  g->vex[src]->first = p;
  ++g->vex[dst]->inCount;
  return 1;
}

// 深度优先遍历 递归形式 start
bool markDFS[100];
void DFS(ALGraph *g, ALNode *n) {
  if (!n) return;
  cout << n->data << " ";
  ArcNode *p = n->first;
  while (p) {
    if (!markDFS[p->adjvex]) {
      markDFS[p->adjvex] = true;
      DFS(g, g->vex[p->adjvex]);
    }
    p = p->next;
  }
}

void DFSALGraph(ALGraph *g) {
  if (!g) return;
  for (int i = 0; i < 100; ++i) {
    markDFS[i] = false;
  }
  for (int i = 0; i < 100; ++i) {
    if (!markDFS[i]) {
      markDFS[i] = true;
      DFS(g, g->vex[i]);
    }
  }
}
// 深度优先遍历 递归形式 start

// 深度优先遍历 非递归形式 start
// todo

// 深度优先遍历 非递归形式 end

// 广度优先遍历 start
bool markBFS[100];
void BFS(ALGraph *g, int vex) {
  markBFS[vex] = true;
  queue<int> q;
  q.push(vex);
  while (!q.empty()) {
    ALNode *p = g->vex[q.front()];
    q.pop();

    ArcNode *edge = p->first;
    while (edge) {
      if (!markBFS[edge->adjvex]) {
        markBFS[edge->adjvex] = true;
        q.push(edge->adjvex);
      }
      edge = edge->next;
    }
  }
}

void BFSALGraph(ALGraph *g) {
  if (!g) return;
  for (int i = 0; i < 100; ++i) {
    markBFS[i] = false;
  }

  for (int i = 0; i < 100; ++i) {
    if (!markBFS[i] && g->vex[i]) {
      BFS(g, i);
    }
  }
}
// 广度优先遍历 end

// 拓扑排序
int TopSort(ALGraph *g) {
  stack<int> s;
  ALNode *p;
  ArcNode *t;
  int sum = 0;
  for (int i = 0; i < 100; ++i) {
    if (g->vex[i]) {
      if (g->vex[i]->inCount == 0) {
        ++sum;
        s.push(i);
      }
    }
  }
  while (!s.empty()) {
    p = g->vex[s.top()];
    s.pop();
    cout << p->data << " ";
    t = p->first;
    while (t) {
      --g->vex[t->adjvex]->inCount;
      if (g->vex[t->adjvex]->inCount == 0) {
        s.push(t->adjvex);
        ++sum;
      }
      t = t->next;
    }
  }
  if (sum == g->vexnum) {
    return 1;
  } else {
    return 0;
  }
}
}  // namespace Map

namespace Search {
typedef struct ListArr {
  int data[100];
  int length;
} ListArr;

typedef struct BTSNode {
  int data;
  struct BTSNode *left, *right;
} BTSNode;

// 顺序搜索
int OrderSearch(ListArr *arr, int x) {
  if (!arr) return -1;
  for (int i = 0; i < arr->length; ++i) {
    if (arr->data[i] == x) {
      return i;
    }
  }
  return -1;
}

// 二分查找
int HalfSearch(ListArr *arr, int x) {
  if (!arr) return -1;
  int l = 0, r = arr->length - 1;
  int mid;
  while (l <= r) {
    mid = (l + r) >> 1;
    if (arr->data[mid] == x) {
      return mid;
    } else if (arr->data[mid] < x) {
      l = mid + 1;
    } else {
      r = mid - 1;
    }
  }
  return -1;
}

// 二分查找树 递归形式
BTSNode *HalfTreeSearch(BTSNode *tree, int x) {
  if (!tree) return NULL;
  if (x == tree->data)
    return tree;
  else if (x < tree->data)
    return HalfTreeSearch(tree->left, x);
  else
    return HalfTreeSearch(tree->right, x);
}

// 二分查找树 非递归形式
BTSNode *HalfTreeSearch2(BTSNode *tree, int x) {
  if (!tree) return NULL;
  BTSNode *p = tree;
  while (p) {
    if (x == p->data)
      return p;
    else if (x < p->data)
      p = p->left;
    else
      p = p->right;
  }
  return NULL;
}
}  // namespace Search

namespace Sort {
typedef struct Arr {
  int data[100];
  int length;
} Arr;

void printfArr(Arr *arr) {
  for (int i = 0; i < arr->length; ++i) {
    printf("%d ", arr->data[i]);
  }
  printf("\n");
}

// 插入排序 从小到大
void InsertSort(Arr *arr) {
  if (!arr) return;
  int t;
  for (int i = 1; i < arr->length; ++i) {
    for (t = i - 1; t >= 0 && arr->data[t] > arr->data[t + 1]; --t) {
      swap(arr->data[t], arr->data[t + 1]);
    }
  }
}

// 折半排序 从小到大
void HalfInsertSort(Arr *arr) {
  if (!arr) return;
  int t, j, l, r, mid;
  for (int i = 1; i < arr->length; ++i) {
    l = 0;
    r = i - 1;
    t = arr->data[i];
    while (l <= r) {
      mid = (l + r) >> 1;
      if (arr->data[mid] > t)
        r = mid - 1;
      else
        l = mid + 1;
    }
    for (j = i - 1; j > r; --j) {
      swap(arr->data[j], arr->data[j + 1]);
    }
  }
}

// 冒泡排序 需要
void BubbleSort(Arr *arr) {
  if (!arr) return;
  bool flag;
  int i, j;
  for (i = 0; i < arr->length; ++i) {
    flag = true;
    for (j = 1; j < arr->length - i; ++j) {
      if (arr->data[j - 1] > arr->data[j]) {
        swap(arr->data[j - 1], arr->data[j]);
        flag = false;
      }
    }
    if (flag) {
      // 一趟下来没有需要调整则已经排序完成
      break;
    }
  }
}

// 快速排序 递归
void QuickSort(Arr *arr, int l, int r) {
  if (!arr) return;
  if (l >= r) return;
  int q = arr->data[l];
  int l0 = l, r0 = r;
  while (l0 < r0) {
    // 从右向左找第一个小于q的值
    while (l0 < r0 && arr->data[r0] > q) {
      --r0;
    }
    if (l0 < r0) {
      arr->data[l0] = arr->data[r0];
      ++l0;
    }

    // 从左向右找第一个大于q的值
    while (l0 < r0 && arr->data[l0] < q) {
      ++l0;
    }
    if (l0 < r0) {
      arr->data[r0] = arr->data[l0];
      --r0;
    }
  }
  arr->data[l0] = q;
  QuickSort(arr, l, l0 - 1);
  QuickSort(arr, l0 + 1, r);
}

// 选择排序
void SelectSort(Arr *arr) {
  if (!arr) return;
  int index;
  for (int i = 0; i < arr->length; ++i) {
    index = i;
    for (int j = i + 1; j < arr->length; ++j) {
      if (arr->data[j] < arr->data[index]) {
        index = j;
      }
    }
    swap(arr->data[index], arr->data[i]);
  }
}

// 堆
void DownSort(Arr *list, int root, int treeNodeSum) {
  int t = root;
  while (true) {
    if (t * 2 + 1 < treeNodeSum && list->data[t] < list->data[t * 2 + 1]) {
      // 左孩子存在且大于根节点
      if (t * 2 + 2 < treeNodeSum &&
          list->data[t * 2 + 2] > list->data[t * 2 + 1]) {
        // 右孩子存在且大于左孩子，右孩子与根节点交换
        swap(list->data[t], list->data[t * 2 + 2]);
        t = t * 2 + 2;
      } else {
        // 右孩子不存在或右孩子小于左孩子，左孩子与根节点交换
        swap(list->data[t], list->data[t * 2 + 1]);
        t = t * 2 + 1;
      }
    } else if (t * 2 + 2 < treeNodeSum &&
               list->data[t] < list->data[t * 2 + 2]) {
      // 右孩子存在，且右孩子大于根节点，且左孩子小于根节点，右孩子与根节点交换
      swap(list->data[t], list->data[t * 2 + 2]);
      t = t * 2 + 2;
    } else {
      // 左右孩子不存在，或存在但小于根节点
      break;
    }
  }
}

void BuildHeap(Arr *list) {
  int root;
  root = (list->length - 2) / 2;
  for (root = (list->length - 2) / 2; root >= 0; --root) {
    DownSort(list, root, list->length);
  }
}

void HeapSort(Arr *list) {
  // 建堆
  BuildHeap(list);

  // 排序
  for (int i = 0; i < list->length; ++i) {
    swap(list->data[0], list->data[list->length - i - 1]);
    DownSort(list, 0, list->length - i - 1);
  }
}

void Test() {
  Arr test1, test2;
  for (int i = 0; i < 9; ++i) {
    test1.data[i] = 10 - i;
    ++test1.length;
  }
  printfArr(&test1);
  // 插入排序
  test2 = test1;
  InsertSort(&test2);
  printfArr(&test2);

  // 折半排序排序
  test2 = test1;
  HalfInsertSort(&test2);
  printfArr(&test2);

  // 冒泡排序排序
  test2 = test1;
  BubbleSort(&test2);
  printfArr(&test2);

  // 冒泡排序排序
  test2 = test1;
  QuickSort(&test2, 0, test2.length - 1);
  printfArr(&test2);

  // 冒泡排序排序
  test2 = test1;
  SelectSort(&test2);
  printfArr(&test2);

  // 堆排序
  test2 = test1;
  HeapSort(&test2);
  printfArr(&test2);
}

}  // namespace Sort

namespace bj7_3 {
const int MAXSIZE = 100;
// 数据结构定义
// 单链表
typedef struct LNode {
  int data;
  struct LNode *next;
} LNode;

// 双链表
typedef struct DLNode {
  int data;
  struct DLNode *prior, *next;
} DLNode;

// 顺序表
typedef struct SeList {
  int data[MAXSIZE];
  int length;
} SeList;

// 二叉树链式存储
typedef struct BTNode {
  int data;
  struct BTNode *left, *right;
} BTNode;

// 图
typedef struct ArcNode {
  int adjnode;
  struct ArcNode *next;
} ArcNode;

typedef struct ALNode {
  int data;
  ArcNode *first;
} ALNode;

typedef struct ALGraph {
  ALNode *vex[MAXSIZE];
  int vexnum;
} ALGraph;

// q1
void InsertSeList(SeList *l, int x) {
  // 假设列表从小到大
  if (!l) return;
  if (l->length == MAXSIZE) return;
  l->data[l->length++] = x;
  for (int i = l->length - 1; i > 0; --i) {
    if (l->data[i] < l->data[i - 1]) {
      swap(l->data[i], l->data[i - 1]);
    } else {
      break;
    }
  }
}

// q2
void MergeLList(LNode *A, LNode *B, LNode *&C) {
  LNode *ta = A->next, *tb = B->next, *tc;
  C = (LNode *)malloc(sizeof(LNode));
  C->next = NULL;
  tc = C;
  while (ta && tb) {
    if (ta->data <= tb->data) {
      tc->next = ta;
      tc = ta;
      ta = ta->next;
    } else {
      tc->next = tb;
      tc = tb;
      tb = tb->next;
    }
  }
  while (ta) {
    tc->next = ta;
    tc = ta;
  }
  while (tb) {
    tc->next = tb;
    tc = tb;
  }
  tc->next = NULL;
}

// q3
void CreatLListRear(vector<int> origin, LNode *&target) {
  target = (LNode *)malloc(sizeof(LNode));
  target->next = NULL;
  LNode *t = target;
  for (int i = 0; i < origin.size(); ++i) {
    t->next = (LNode *)malloc(sizeof(LNode));
    t = t->next;
    t->data = origin[i];
  }
  t->next = NULL;
}

// q4
void CreatLListFront(SeList *origin, LNode *&target) {
  target = (LNode *)malloc(sizeof(LNode));
  target->next = NULL;
  LNode *t;
  for (int i = 0; i < origin->length; ++i) {
    t = (LNode *)malloc(sizeof(LNode));
    t->next = target->next;
    t->data = origin->data[i];
    target->next = t;
  }
}

// q5
int SearchDelLList(LNode *list, int x) {
  if (!list) return -1;
  LNode *t = list->next;
  LNode *q = list;  // 用于删除节点时的操作
  while (t) {
    if (t->data == x) {
      // 删除此t节点
      q->next = t->next;
      free(t);
      return 1;
    }
    q = t;
    t = t->next;
  }
  return 0;
}

// q6
void CreatDLListRear(SeList *origin, DLNode *&target) {
  DLNode *t;
  target = (DLNode *)malloc(sizeof(DLNode));
  target->next = target->prior = NULL;
  t = target;
  for (int i = 0; i < origin->length; ++i) {
    t->next = (DLNode *)malloc(sizeof(DLNode));
    t->next->prior = t;
    t = t->next;
    t->data = origin->data[i];
  }
  t->next = NULL;
}

// q6.5 头插法
void CreatDLListFront(SeList *origin, DLNode *&target) {
  DLNode *t;
  target = (DLNode *)malloc(sizeof(DLNode));
  target->prior = target->next = NULL;
  for (int i = origin->length - 1; i >= 0; --i) {
    t = (DLNode *)malloc(sizeof(DLNode));
    t->data = origin->data[i];
    t->next = target->next;
    target->next->prior = t;
    target->next = t;
  }
  target->next->prior = target;  // 最后第一个元素的prior指向头节点
}

// q7
void InsertDLNode(DLNode *p, DLNode *s) {
  s->next = p->next;
  p->next->prior = s;
  p->next = s;
  s->prior = p;
}

// q8
void DelDLNode(DLNode *p) {
  DLNode *t = p->next;
  p->next = t->next;
  p->next->prior = p;
  free(t);
}

// q9
void LListADelB(LNode *&A, LNode *&B) {
  LNode *ta = A->next, *tb = B->next;
  LNode *prea = A;  // 用以删除ta节点
  while (ta && tb) {
    if (tb->data < ta->data) {
      tb = tb->next;
    } else if (ta->data > tb->data) {
      prea = ta;
      ta = ta->next;
    } else {
      // 相等，删除该ta节点
      prea->next = ta->next;
      free(ta);
      ta = prea->next;
    }
  }
}

// q10
void ReverseSeList(SeList *list) {
  int l = 0, r = list->length - 1;
  while (l < r) {
    swap(list->data[l], list->data[r]);
    ++l;
    --r;
  }
}

// q11
void DelRangeSeList(SeList *list, int start, int end) {
  int len = end - start + 1;
  for (int i = end + 1; i < list->length; ++i) {
    list->data[i - len] = list->data[i];
  }
  list->length -= len;
}

// q12
void SeListSort(SeList *list) {
  int l = 0, r = list->length - 1;
  int t = list->data[0];
  while (l < r) {
    // 从后向前找第一个小于t的值
    while (l < r && list->data[r] > t) --r;
    if (l < r) {
      list->data[l] = list->data[r];
      ++l;
    }

    // 从前向后找第一个大于t的值
    while (l < r && list->data[l] < t) ++l;
    if (l < r) {
      list->data[r] = list->data[l];
      --r;
    }
  }
  list->data[l] = t;
}

// q13
void DelDuplicateNode(LNode *list) {
  LNode *p = list->next;
  LNode *t;
  if (!p) return;  // 如果列表只有一项直接退出
  while (p->next) {
    if (p->next->data == p->data) {
      // 重复节点 删除
      t = p->next;
      p->next = t->next;
      free(t);
    } else {
      p = p->next;
    }
  }
}

// q14
void DelMinNode(LNode *list) {
  LNode *p = list->next;
  if (!p) return;  // 如果为空列表
  LNode *minNode = p, *prior = list, *minPrior = list;
  int minVal = minNode->data;
  p = p->next;
  while (p) {
    if (p->data < minVal) {
      minVal = p->data;
      minNode = p;
      minPrior = prior;
    }
    prior = p;
    p = p->next;
  }

  // 删除最小节点
  minPrior->next = minNode->next;
  free(minNode);
}

// q15
void ReverseList(LNode *list) {
  LNode *target, *q, *p;
  target = (LNode *)malloc(sizeof(LNode));
  p = list->next;
  while (p) {
    q = p->next;
    p->next = target->next;
    target->next = p;
    p = q;
  }
  list->next = target->next;
  free(target);
}

// q16
void SplitAToBList(LNode *A, LNode *&B) {
  B = (LNode *)malloc(sizeof(LNode));
  B->next = NULL;
  LNode *pa, *prea;
  pa = A->next;
  prea = A;
  while (pa) {
    if (pa->data % 2 == 1) {
      prea->next = pa->next;
      pa->next = B->next;
      B->next = pa;
      pa = prea->next;
    } else {
      prea = pa;
      pa = pa->next;
    }
  }
}

// q17
void ReversePrintf(LNode *list) {
  stack<int> s;
  LNode *p = list->next;
  while (p) {
    s.push(p->data);
    p = p->next;
  }
  while (!s.empty()) {
    printf("%d ", s.top());
    s.pop();
  }
}

// q18
LNode *SearchLastKNode(LNode *list, int k) {
  LNode *p = list->next;
  LNode *target = list;
  int index = -k;
  while (p) {
    ++index;
    if (index >= 0) {
      target = target->next;
    }
    p = p->next;
  }
  printf("%d\n", target->data);
  return target;
}

// q19
void RangeReverseSeList(SeList *list, int p) {
  int l, r;
  if (p < 0 || p >= list->length) return;
  // 整体翻转
  l = 0;
  r = list->length - 1;
  while (l < r) {
    swap(list->data[l], list->data[r]);
    ++l;
    --r;
  }

  // 翻转0-(n-p-1)
  l = 0;
  r = list->length - p - 1;
  while (l < r) {
    swap(list->data[l], list->data[r]);
    ++l;
    --r;
  }

  // 翻转(n-p) - (n-1)
  l = list->length - p;
  r = list->length - 1;
  while (l < r) {
    swap(list->data[l], list->data[r]);
    ++l;
    --r;
  }
}

// q20
int Brackets(char exp[]) {
  stack<char> s;
  char *p = exp;
  while (*p != '\0') {
    // 括号起始
    if (*p == '(')
      s.push(*p);
    else if (*p == '[')
      s.push(*p);
    else if (*p == '{')
      s.push(*p);

    // 括号结束
    else if (*p == ')') {
      if (s.top() == '(') {
        s.pop();
      } else {
        return -1;
      }
    } else if (*p == ']') {
      if (s.top() == '[') {
        s.pop();
      } else {
        return -1;
      }
    } else if (*p == '}') {
      if (s.top() == '{') {
        s.pop();
      } else {
        return -1;
      }
    }

    // 单引号和双引号
    else if (*p == 39) {
      ++p;
      while (*p != '\0' && *p != 39) ++p;
      if (*p == '\0') return -1;
    } else if (*p == 34) {
      ++p;
      while (*p != '\0' && *p != 34) ++p;
      if (*p == '\0') return -1;
    }

    ++p;
  }

  if (s.empty()) {
    return 0;
  } else {
    return -1;
  }
}

// q21
double CalcExp(char exp[]) {
  char *p = exp;
  stack<double> s;
  double a, b;
  while (*p != '\0') {
    if ('0' <= *p && *p <= '9') {
      s.push(*p - '0');
    } else if (*p == '+' || *p == '-' || *p == '*' || *p == '/') {
      b = s.top();
      s.pop();
      a = s.top();
      s.pop();
      if (*p == '+') {
        s.push(a + b);
      } else if (*p == '-') {
        s.push(a - b);
      } else if (*p == '*') {
        s.push(a * b);
      } else {
        s.push(a / b);
      }
    }
    ++p;
  }
  return s.top();
}

// q22
typedef struct ShareStack {
  int data[MAXSIZE];
  int s0, s1;
} ShareStack;

void InitShareStack(ShareStack *s) {
  s->s0 = -1;
  s->s1 = MAXSIZE;
}

int TopShareStack(ShareStack *s, int index, int &ret) {
  if (index == 1) {
    if (s->s0 >= 0) {
      ret = s->data[s->s0];
      return 0;
    } else {
      return -1;
    }
  } else if (index == 2) {
    if (s->s0 < MAXSIZE) {
      ret = s->data[s->s1];
      return 0;
    } else {
      return -1;
    }
  } else {
    return -2;
  }
}

int PopShareStack(ShareStack *s, int index) {
  if (index == 1) {
    if (s->s0 >= 0) {
      --s->s0;
      return 0;
    } else {
      return -1;
    }
  } else if (index == 2) {
    if (s->s0 < MAXSIZE) {
      ++s->s1;
      return 0;
    } else {
      return -1;
    }
  } else {
    return -2;
  }
}

int PushShareStack(ShareStack *s, int index, int x) {
  if (index == 1) {
    if (s->s0 + 1 != s->s1) {
      s->data[++s->s0] = x;
      return 0;
    } else {
      return -1;
    }
  } else if (index == 2) {
    if (s->s0 + 1 != s->s1) {
      s->data[--s->s1] = x;
      return 0;
    } else {
      return -1;
    }
  } else {
    return -2;
  }
}

// q23
void EnQueueList(LNode *&list, int x) {
  LNode *t = (LNode *)malloc(sizeof(LNode));
  t->data = x;
  t->next = list->next;
  list->next = t;
  list = t;
}
int OutQueueList(LNode *&list, int &x) {
  LNode *t;
  if (list->next == list) return -1;  // 空队列
  t = list->next->next;
  x = t->data;
  list->next->next = t->next;
  if (t == list) {
    // 队列为空
    list = list->next;
  }
  free(t);
  return 0;
}

// q24
typedef struct CycQueue {
  int data[MAXSIZE];
  int front, rear;
} CycQueue;

void InitCycQueue(CycQueue *q) {
  q->front = 0;
  q->rear = 0;
}

int EnCycQueue(CycQueue *q, int x) {
  if ((q->rear + 1) % MAXSIZE == q->front) {
    // 队列满
    return -1;
  }
  q->data[q->front--] = x;
  if (q->front < 0) {
    q->front = MAXSIZE - 1;
  }
  return 0;
}

int OutCycQueue(CycQueue *q, int &x) {
  if (q->front == q->rear) {
    // 队列空
    return -1;
  }
  x = q->data[q->rear--];
  if (q->rear < 0) {
    q->rear = MAXSIZE - 1;
  }
  return 0;
}

// q25
typedef struct CycQueue2 {
  int data[MAXSIZE];
  int front, rear;
  int tag;  // tag==0 队空; tag==1 队非空
} CycQueue2;

void InitCycQueue2(CycQueue2 *q) {
  q->front = q->rear = 0;
  q->tag = 0;
}

int EnCycQueue2(CycQueue2 *q, int x) {
  if (q->front == q->rear && q->tag == 1) {
    // 队满
    return -1;
  }

  q->data[q->rear++] = x;
  q->rear = (q->rear + MAXSIZE) % MAXSIZE;
  q->tag = 1;
  return 0;
}

int OutCycQueue2(CycQueue2 *q, int &x) {
  if (q->tag == 0) {
    // 队空
    return -1;
  }
  x = q->data[q->front++];
  q->front = q->front >= MAXSIZE ? 0 : q->front;
  if (q->front == q->rear) {
    q->tag = 0;
  }
  return 0;
}

// q26
// 求A的平方根 p为A的近似平方根 e为允许的误差
double sqrt1(double A, double p, double e) {
  if (fabs(p * p - A) < e) {
    return p;
  } else {
    return sqrt1(A, p + A / p, e);
  }
}

double sqrt2(double A, double p, double e) {
  while (fabs(p * p - A) >= e) {
    p = p + A / p;
  }
  return p;
}

// q27
void ReverseString(string str) {
  int l = 0, r = str.length() - 1;
  while (l < r) {
    swap(str[l], str[r]);
  }
}

// q28
int CalcOccurNum(string str, string substr) {
  int rangeStr = str.length() - substr.length();
  bool flag;
  int ret = 0;
  for (int i = 0; i <= rangeStr; ++i) {
    flag = true;
    for (int j = 0; j < substr.length(); ++j) {
      if (str[i + j] != substr[j]) {
        flag = false;
        break;
      }
    }
    if (flag) {
      ++ret;
    }
  }
  return ret;
}

// q29
void MoveAllZeroToTop(int data[], int n) {
  int sumNoZero = 0, r;
  for (r = 0; r < n; ++r) {
    if (data[r] != 0) {
      ++sumNoZero;
      if (sumNoZero - 1 < r) {
        swap(data[sumNoZero - 1], data[r]);
      }
    }
  }
}

// q30
// 求二叉树宽度，前面写过了

// q31
char FirstSameAncestor(char tree[], int i, int j) {
  int l = i, r = j;
  while (l != j) {
    if (l < r) {
      r = r / 2;
    } else {
      l = l / 2;
    }
  }
  return tree[l];
}

// q32
BTNode *CreateTree(vector<int> preOrder, vector<int> inOrder) {
  if (preOrder.size() == 0) return NULL;
  BTNode *root = (BTNode *)malloc(sizeof(BTNode));
  root->data = preOrder[0];
  vector<int> preOrderLeft, preOrderRight, inOrderLeft, inOrderRight;
  int rootIn, j;
  // 在中序遍历中找根 并且生成左子树的中序遍历
  for (rootIn = 0; inOrder[rootIn] != preOrder[0]; ++rootIn) {
    inOrderLeft.push_back(inOrder[rootIn]);
  }
  // rootIn 既是中序遍历的根的下标
  // 又是左子树节点个数
  // 生成左子树的先序遍历
  for (j = 1; j <= rootIn; ++j) {
    preOrderLeft.push_back(preOrder[j]);
  }

  // 生成右子树先序遍历
  for (j = rootIn + 1; j < preOrder.size(); ++j) {
    preOrderRight.push_back(preOrder[j]);
  }

  // 生成右子树中序遍历
  for (j = rootIn + 1; j < inOrder.size(); ++j) {
    inOrderRight.push_back(inOrder[j]);
  }

  // 递归生成左右子树
  root->left = CreateTree(preOrderLeft, inOrderLeft);
  root->right = CreateTree(preOrderRight, inOrderRight);
  return root;
}

// q33
BTNode *head_q33 = NULL, *rear_q33 = NULL;
void ConnectLeafNode(BTNode *tree) {
  if (!tree) return;
  if (tree->left == NULL && tree->right == NULL) {
    // 叶子节点
    if (!head_q33) {
      head_q33 = rear_q33 = tree;
    } else {
      rear_q33->right = tree;
      rear_q33 = tree;
    }
  } else {
    ConnectLeafNode(tree->left);
    ConnectLeafNode(tree->right);
  }
}

// q34
void TransferPreToIn(vector<int> pre, int l0, int r0, vector<int> post, int l1,
                     int r1) {
  if (l0 <= r0) {
    // 根
    post[r1] = pre[l0];

    // 左子树
    TransferPreToIn(pre, l0 + 1, (l0 + r0) >> 1, post, l1, (l1 + r1) >> 1 - 1);

    // 右子树
    TransferPreToIn(pre, (l0 + r0) >> 1 + 1, r0, post, (l1 + r1) >> 1, r1 - 1);
  }
}

// q35
stack<int> s_q35;
void PrintfAllLeafPath(BTNode *tree) {
  if (!tree) return;
  if (tree->left == NULL && tree->right == NULL) {
    // 叶子节点
    stack<int> t(s_q35);
    printf("%d ", tree->data);
    while (!t.empty()) {
      printf("%d ", t.top());
      t.pop();
    }
    printf("\n");
  } else {
    s_q35.push(tree->data);
    PrintfAllLeafPath(tree->left);
    PrintfAllLeafPath(tree->right);
    s_q35.pop();
  }
}

// q36
int SearchFurthestNode(ALGraph *g, int x) {
  if (!g) return -1;
  if (g->vex[x] == NULL) return -1;

  queue<int> q;
  int i, t;
  bool flag;
  ArcNode *edge;
  q.push(x);
  while (!q.empty()) {
    flag = true;
    for (i = q.size(); i > 0; --i) {
      t = q.front();
      q.pop();
      edge = g->vex[t]->first;
      while (edge) {
        q.push(edge->adjnode);
        edge = edge->next;
        flag = false;
      }
    }
    if (flag) {
      // 没有新进的点
      return t;
    }
  }
  return t;
}

// q37
int SearchExistPath(ALGraph *g, int vi, int vj) {
  if (!g) return -1;
  if (g->vex[vi] == NULL) return 0;
  if (g->vex[vj] == NULL) return 0;

  queue<int> q;
  int i, t;
  ArcNode *edge;
  q.push(vi);
  while (!q.empty()) {
    for (i = q.size(); i > 0; --i) {
      t = q.front();
      q.pop();
      if (t == vj) {
        // 有路径连通
        return 1;
      }
      edge = g->vex[t]->first;
      while (edge) {
        q.push(edge->adjnode);
        edge = edge->next;
      }
    }
  }
  return 0;
}

// q38
int visit_q38[MAXSIZE], sum_q38;
void DFSGraph(ALGraph *g, int x) {
  if (!visit_q38[x]) {
    visit_q38[x] = 1;
    ++sum_q38;
  } else {
    return;
  }

  ArcNode *edge = g->vex[x]->first;
  while (edge) {
    DFSGraph(g, edge->adjnode);
    edge = edge->next;
  }
}

int GetRootNodeGraph(ALGraph *g) {
  if (!g) return -1;
  for (int i = 0; i < g->vexnum; ++i) {
    for (int j = 0; j < g->vexnum; ++j) {
      visit_q38[j] = 0;
    }
    sum_q38 = 0;
    DFSGraph(g, i);
    if (sum_q38 == g->vexnum) {
      printf("%d ", i);
    }
  }
  return 0;
}

// q39
int GetInDegree(ALGraph *g, int x) {
  if (!g) return -1;
  if (!g->vex[x]) return -1;

  ArcNode *edge;
  int ret = 0;
  for (int i = 0; i < g->vexnum; ++i) {
    edge = g->vex[i]->first;
    while (edge) {
      if (edge->adjnode == x) {
        ++ret;
      }
    }
  }
  return ret;
}

// q40
BTNode *InsertBTree(BTNode *tree, int x) {
  if (!tree) return NULL;

  BTNode *t;
  if (x < tree->data) {
    if (tree->left) {
      return InsertBTree(tree->left, x);
    } else {
      t = (BTNode *)malloc(sizeof(BTNode));
      t->data = x;
      t->left = t->right = NULL;
      // t->count = 1;
      tree->left = t;
      return t;
    }
  } else if (x > tree->data) {
    if (tree->right) {
      return InsertBTree(tree->right, x);
    } else {
      t = (BTNode *)malloc(sizeof(BTNode));
      t->data = x;
      t->left = t->right = NULL;
      // t->count = 1;
      tree->right = t;
      return t;
    }
  } else {
    // ++tree->count;
    return tree;
  }
}

// q41
// -1 列表不存在
// 1 中心对称
// 0 非中心对称
int IsCenter(LNode *list, int n) {
  if (!list) return -1;
  if (!list->next) return 1;
  stack<int> s;
  LNode *t = list->next;
  int index = 0;
  while (t && index < n / 2) {
    ++index;
    s.push(t->data);
    t = t->next;
  }

  // 长度为奇数，越过中心点
  if (n % 2 == 1) {
    t = t->next;
  }

  while (t) {
    if (s.top() != t->data) {
      return 0;
    }
    s.pop();
    t = t->next;
  }
  return 1;
}

// q42 不知道什么意思

// q43
int ExistLoopList(LNode *list) {
  if (!list) return -1;
  // if(!list->next) return 1; // 空链表

  LNode *p1 = list, *p2 = list->next;
  while (p1 && p2 && p1 != p2) {
    p1 = p1->next;
    if (p2->next) {
      p2 = p2->next->next;
    } else {
      return 0;
    }
  }
  if (p1 == p2) {
    return 1;
  } else {
    return 0;
  }
}

// q44
long long Pnx(int n, int x) {
  if (n == 1) return 1;
  if (n == 2) return 2 * x;
  stack<long long> s;
  s.push(1);
  s.push(2 * x);
  long long pr1, pr2;
  for (int i = 3; i <= n; ++i) {
    pr2 = s.top();
    s.pop();
    pr1 = s.top();
    s.pop();
    s.push(pr2);
    s.push(2 * (x * pr2 - (i - 1) * pr1));
  }
  return s.top();
}

// q45

// 先序遍历 非递归
void preOrder_q45(BTNode *tree) {
  if (!tree) return;
  stack<BTNode *> s;
  BTNode *t;
  s.push(tree);
  while (!s.empty()) {
    t = s.top();
    s.pop();
    printf("%d ", t->data);
    if (t->right) {
      s.push(t->right);
    }
    if (t->left) {
      s.push(t->left);
    }
  }
}

// 中序遍历 非递归
void inOrder_q45(BTNode *tree) {
  if (!tree) return;
  BTNode *t;
  pair<BTNode *, int> p;
  // stack<BTNode *> s;
  stack<pair<BTNode *, int>> s;
  if (tree->left || tree->right) {
    // 非叶子节点
    s.push(pair<BTNode *, int>(tree, 1));
  } else {
    printf("%d ", tree->data);
    return;
  }
  while (!s.empty()) {
    p = s.top();
    t = p.first;
    s.pop();
    if (p.second == 1) {
      // 第一次拿出来
      if (t->left || t->right) {
        // 非叶子节点
        if (t->right) s.push(pair<BTNode *, int>(t->right, 1));
        s.push(pair<BTNode *, int>(t, 0));
        if (t->left) s.push(pair<BTNode *, int>(t->left, 1));
      } else {
        // 叶子节点
        printf("%d ", t->data);
      }
    } else {
      // 第二次拿出来
      printf("%d ", t->data);
    }
  }
}

// 后序遍历 非递归
void postOrder_q45(BTNode *tree) {
  if (!tree) return;
  BTNode *t;
  pair<BTNode *, int> p;
  stack<pair<BTNode *, int>> s;
  if (tree->left || tree->right) {
    // 非叶子节点
    s.push(make_pair(tree, 1));
  } else {
    printf("%d ", tree->data);
    return;
  }
  while (!s.empty()) {
    p = s.top();
    t = p.first;
    s.pop();
    if (p.second == 1) {
      // 第一次拿出来
      if (t->left || t->right) {
        // 非叶子节点
        s.push(pair<BTNode *, int>(t, 0));
        if (t->right) s.push(make_pair(t->right, 1));
        if (t->left) s.push(make_pair(t->left, 1));
      } else {
        // 叶子节点
        printf("%d ", t->data);
      }
    } else {
      // 第二次拿出来
      printf("%d ", t->data);
    }
  }
}

// q46
// 1 是完全二叉树
// 0 不是完全二叉树
int IsCompleteBTree(BTNode *tree) {
  if (!tree) return 1;
  int dep = 1;
  BTNode *t;
  queue<BTNode *> q;
  q.push(tree);
  while (!q.empty()) {
    if (q.size() != pow(2, dep - 1)) {
      return 0;
    }
    for (int i = q.size(); i > 0; --i) {
      t = q.front();
      q.pop();
      if (t->left) q.push(t->left);
      if (t->right) q.push(t->right);
    }
  }
  return 1;
}

// q47
string ReverseWord(string str) {
  string ret = str;
  int l = 0, r = ret.length() - 1;
  // 整体翻转一次
  while (l < r) {
    swap(ret[l], ret[r]);
    ++l;
    --r;
  }

  // 每个单词翻转一次
  l = 0;
  for (int i = 0; i < ret.length(); ++i) {
    if (ret[i] == ' ') {
      // 空格，之前是一个单词，翻转上一个单词
      r = i - 1;
      while (l < r) {
        swap(ret[l], ret[r]);
        ++l;
        --r;
      }
      l = i + 1;
    }
  }
  if (l != ret.length() - 1) {
    // 最后一个单词
    r = ret.length() - 1;
    while (l < r) {
      swap(ret[l], ret[r]);
      ++l;
      --r;
    }
  }
  return ret;
}

// q48
// 0 未找到
// 1 找到了
int SearchXAncestor(BTNode *tree, int x) {
  if (!tree) return 0;
  int ret;
  if (tree->data == x) {
    return 1;
  } else {
    ret = SearchXAncestor(tree->left, x);
    if (ret == 1) {
      printf("%d ", tree->data);
      return 1;
    }
    ret = SearchXAncestor(tree->right, x);
    if (ret == 1) {
      printf("%d ", tree->data);
      return 1;
    }
    return 0;
  }
}

}  // namespace bj7_3

void freeTree(bj7_3::BTNode *tree) {
  if (tree) {
    if (tree->left) {
      freeTree(tree->left);
    }
    if (tree->right) {
      freeTree(tree->right);
    }
    free(tree);
  }
}

int insertBTNode(bj7_3::BTNode *tree, int src, int x, bool isleft) {
  if (tree) {
    if (tree->data == src) {
      bj7_3::BTNode *t = (bj7_3::BTNode *)malloc(sizeof(bj7_3::BTNode));
      t->data = x;
      t->left = t->right = NULL;
      if (isleft) {
        tree->left = t;
      } else {
        tree->right = t;
      }
      return 1;
    } else {
      if (!insertBTNode(tree->left, src, x, isleft)) {
        return insertBTNode(tree->right, src, x, isleft);
      } else {
        return 1;
      }
    }
  } else {
    return 0;
  }
}

void BuildTree(bj7_3::BTNode *&tree) {
  FILE *file = fopen("BTree.txt", "r");
  int n, node, parent, isLeft;
  fscanf(file, "%d", &n);
  for (int i = 0; i < n; ++i) {
    fscanf(file, "%d %d %d", &node, &parent, &isLeft);
    if (parent == 0) {
      tree = (bj7_3::BTNode *)malloc(sizeof(bj7_3::BTNode));
      tree->data = node;
      tree->left = tree->right = NULL;
    } else {
      insertBTNode(tree, parent, node, isLeft == 1 ? true : false);
    }
  }
  fclose(file);
}

void TestTreeOrder() {
  bj7_3::BTNode *tree;
  BuildTree(tree);
  bj7_3::preOrder_q45(tree);
  printf("\n");
  bj7_3::inOrder_q45(tree);
  printf("\n");
  bj7_3::postOrder_q45(tree);
  printf("\n");
  freeTree(tree);
}

void adsf(vector<int> a) {}

class Base {
 public:
  int Bar(char x) { return (int)x; }
  virtual int Bar(int x) { return (2 * x); }
};

class Derived : public Base {
 public:
  int Bar(char x) { return (int)(-x); }
  int Bar(int x) { return (x / 2); }
};

int main() {
  // TestTreeOrder();
  // Sort::Test();

  Base *pa = (Base *)new Derived();
  cout << pa->Bar(10) << endl;

  int a[10][10];
  cout << *(*(a + 3) + 1) << endl;

  return 0;
}
